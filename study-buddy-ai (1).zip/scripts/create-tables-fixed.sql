-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  name VARCHAR(255),
  xp INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create quiz_history table
CREATE TABLE IF NOT EXISTS quiz_history (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_email VARCHAR(255) NOT NULL,
  topic VARCHAR(255) NOT NULL,
  total_questions INTEGER NOT NULL,
  correct_answers INTEGER NOT NULL,
  xp_earned INTEGER NOT NULL,
  completed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_profiles_email ON profiles(email);
CREATE INDEX IF NOT EXISTS idx_profiles_xp ON profiles(xp DESC);
CREATE INDEX IF NOT EXISTS idx_quiz_history_user_email ON quiz_history(user_email);
CREATE INDEX IF NOT EXISTS idx_quiz_history_completed_at ON quiz_history(completed_at DESC);

-- Enable Row Level Security
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE quiz_history ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Users can view their own profile" ON profiles;
DROP POLICY IF EXISTS "Users can update their own profile" ON profiles;
DROP POLICY IF EXISTS "Users can insert their own profile" ON profiles;
DROP POLICY IF EXISTS "Public can view leaderboard" ON profiles;
DROP POLICY IF EXISTS "Users can view their own quiz history" ON quiz_history;
DROP POLICY IF EXISTS "Users can insert their own quiz history" ON quiz_history;

-- Create policies for profiles table
-- Allow authenticated users to insert their own profile
CREATE POLICY "Enable insert for authenticated users" ON profiles
  FOR INSERT 
  TO authenticated
  WITH CHECK (auth.email() = email);

-- Allow users to view their own profile
CREATE POLICY "Enable select for users based on email" ON profiles
  FOR SELECT 
  TO authenticated
  USING (auth.email() = email);

-- Allow users to update their own profile
CREATE POLICY "Enable update for users based on email" ON profiles
  FOR UPDATE 
  TO authenticated
  USING (auth.email() = email)
  WITH CHECK (auth.email() = email);

-- Allow public read access for leaderboard (only email, name, xp fields)
CREATE POLICY "Enable select for leaderboard" ON profiles
  FOR SELECT 
  TO authenticated
  USING (true);

-- Create policies for quiz_history table
CREATE POLICY "Enable insert for authenticated users" ON quiz_history
  FOR INSERT 
  TO authenticated
  WITH CHECK (auth.email() = user_email);

CREATE POLICY "Enable select for users based on email" ON quiz_history
  FOR SELECT 
  TO authenticated
  USING (auth.email() = user_email);

-- Create a function to handle new user creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.profiles (email, name, xp, created_at)
  VALUES (
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1)),
    0,
    NOW()
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to automatically create profile on user signup
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
