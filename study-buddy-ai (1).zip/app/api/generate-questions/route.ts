import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { topic } = await request.json()

    if (!topic || !topic.trim()) {
      return NextResponse.json({ error: "Topic is required" }, { status: 400 })
    }

    // Check if Gemini API key is available
    if (!process.env.GOOGLE_GEMINI_API_KEY) {
      console.log("Gemini API key not found, returning demo questions")
      return NextResponse.json({ questions: generateDemoQuestions(topic) })
    }

    try {
      // Updated API endpoint - using the correct Gemini API URL
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key=${process.env.GOOGLE_GEMINI_API_KEY}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            contents: [
              {
                parts: [
                  {
                    text: `Create comprehensive practice questions for the topic: "${topic}". 

Please provide a variety of question types:

1. **Multiple Choice Questions (5 questions)**
   - Include 4 options each (A, B, C, D)
   - Mark the correct answer
   - Test key concepts and understanding

2. **Short Answer Questions (5 questions)**
   - Questions that require 2-3 sentence answers
   - Focus on explanations and definitions

3. **Essay Questions (3 questions)**
   - Questions requiring detailed responses
   - Test deeper understanding and analysis

4. **True/False Questions (5 questions)**
   - Include explanations for the correct answers
   - Cover important facts and concepts

5. **Application Questions (3 questions)**
   - Real-world scenarios and problem-solving
   - Test practical understanding

Format the questions clearly with proper numbering and sections. Make them educational and appropriate for studying ${topic}.`,
                  },
                ],
              },
            ],
            generationConfig: {
              temperature: 0.7,
              topK: 40,
              topP: 0.95,
              maxOutputTokens: 2048,
            },
          }),
        },
      )

      if (!response.ok) {
        console.error(`Gemini API error: ${response.status} ${response.statusText}`)
        return NextResponse.json({ questions: generateDemoQuestions(topic) })
      }

      const data = await response.json()

      // Check if the response has the expected structure
      if (
        !data.candidates ||
        !data.candidates[0] ||
        !data.candidates[0].content ||
        !data.candidates[0].content.parts ||
        !data.candidates[0].content.parts[0]
      ) {
        console.error("Unexpected API response structure:", data)
        return NextResponse.json({ questions: generateDemoQuestions(topic) })
      }

      const questions = data.candidates[0].content.parts[0].text
      return NextResponse.json({ questions })
    } catch (apiError) {
      console.error("Gemini API request failed:", apiError)
      return NextResponse.json({ questions: generateDemoQuestions(topic) })
    }
  } catch (error) {
    console.error("Error in questions generation:", error)
    return NextResponse.json({ questions: generateDemoQuestions("General Study Topic") })
  }
}

function generateDemoQuestions(topic: string): string {
  return `# Practice Questions: ${topic}

## 📝 Multiple Choice Questions

**1. What is the primary focus when studying ${topic}?**
A) Memorizing isolated facts
B) Understanding core concepts and their relationships
C) Avoiding practical applications
D) Learning without context

*Correct Answer: B*

**2. Which approach is most effective for mastering ${topic}?**
A) Passive reading only
B) Active engagement with examples and practice
C) Avoiding questions and discussions
D) Studying without structure

*Correct Answer: B*

**3. How does ${topic} relate to real-world applications?**
A) It has no practical relevance
B) It only applies in academic settings
C) It provides tools for solving practical problems
D) It's purely theoretical

*Correct Answer: C*

**4. What is the best way to approach complex concepts in ${topic}?**
A) Ignore difficult parts
B) Memorize without understanding
C) Break them into smaller, manageable parts
D) Study everything at once

*Correct Answer: C*

**5. How should you review material related to ${topic}?**
A) Study once and never review
B) Use spaced repetition and regular practice
C) Avoid making connections
D) Focus only on memorization

*Correct Answer: B*

## ✍️ Short Answer Questions

**1. Explain the fundamental importance of studying ${topic}.**
*Expected Answer: Should discuss core concepts, practical applications, and how it builds foundational knowledge for further learning.*

**2. Describe three key strategies for effectively learning ${topic}.**
*Expected Answer: Should mention active learning, practice, making connections, and regular review.*

**3. How can you apply knowledge of ${topic} in practical situations?**
*Expected Answer: Should provide specific examples of real-world applications and problem-solving scenarios.*

**4. What are the main challenges students face when learning ${topic}?**
*Expected Answer: Should identify common difficulties and suggest strategies to overcome them.*

**5. Explain how ${topic} connects to other areas of study.**
*Expected Answer: Should demonstrate understanding of interdisciplinary connections and broader context.*

## 📖 Essay Questions

**1. Analyze the historical development and current significance of ${topic}. Discuss how understanding has evolved and what future developments might be expected.**

**2. Compare and contrast different approaches to studying ${topic}. Evaluate the effectiveness of various learning strategies and recommend the best practices for different types of learners.**

**3. Examine the practical applications of ${topic} in modern society. Provide specific examples and discuss the implications for future developments in this field.**

## ✅ True/False Questions

**1. True or False: ${topic} can only be understood through memorization.**
*Answer: False - Understanding requires active engagement and application of concepts.*

**2. True or False: Regular practice is essential for mastering ${topic}.**
*Answer: True - Consistent practice helps reinforce learning and build expertise.*

**3. True or False: ${topic} has no connection to other subjects.**
*Answer: False - Most subjects are interconnected and build upon each other.*

**4. True or False: Visual aids and diagrams can help in understanding ${topic}.**
*Answer: True - Visual learning tools can enhance comprehension and retention.*

**5. True or False: Group study is always more effective than individual study for ${topic}.**
*Answer: False - Effectiveness depends on individual learning style and the specific material.*

## 🔬 Application Questions

**1. Scenario: You need to explain ${topic} to someone with no background knowledge. How would you structure your explanation and what examples would you use?**

**2. Problem-Solving: Given a real-world situation where knowledge of ${topic} is crucial, outline the steps you would take to analyze and address the problem.**

**3. Critical Thinking: Evaluate a common misconception about ${topic}. Explain why it's incorrect and provide evidence to support the accurate understanding.**

---

## 📚 Study Tips for These Questions:

- **Multiple Choice**: Focus on understanding concepts rather than memorizing answers
- **Short Answer**: Practice explaining concepts clearly and concisely
- **Essay Questions**: Develop your ability to analyze and synthesize information
- **True/False**: Pay attention to absolute terms and exceptions
- **Application**: Think about real-world connections and practical uses

*Note: This is a demo question set. For AI-generated, topic-specific questions, please ensure the Gemini API is properly configured.*`
}
