import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const image = formData.get("image") as File

    if (!image) {
      return NextResponse.json({ error: "No image provided" }, { status: 400 })
    }

    // Simulate processing delay
    await new Promise((resolve) => setTimeout(resolve, 2000))

    // Demo extracted text
    const extractedText = `Demo extracted text from "${image.name}":

This appears to be a mathematical equation or problem. The image contains text that would normally be extracted using OCR (Optical Character Recognition) technology.

Sample problem: "Solve for x: 2x + 5 = 15"`

    // Demo AI response
    const aiResponse = `**Problem Analysis:**
I can see this appears to be a linear equation problem. Let me solve it step by step.

**Given Problem:** 2x + 5 = 15

**Step-by-Step Solution:**

1. **Subtract 5 from both sides:**
   2x + 5 - 5 = 15 - 5
   2x = 10

2. **Divide both sides by 2:**
   2x ÷ 2 = 10 ÷ 2
   x = 5

**Final Answer:** x = 5

**Verification:**
Let's check: 2(5) + 5 = 10 + 5 = 15 ✓

**Key Concepts:**
- Linear equations
- Inverse operations
- Algebraic manipulation

**Similar Problems:**
You can solve similar equations by:
1. Isolating the variable term
2. Using inverse operations
3. Always checking your answer

This is a demo response. In a real implementation, I would analyze your actual image and provide specific solutions to your questions!`

    return NextResponse.json({
      extractedText,
      aiResponse,
    })
  } catch (error) {
    console.error("Error in demo processing:", error)
    return NextResponse.json({ error: "Demo processing failed" }, { status: 500 })
  }
}
