import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { topic, questionCount = 5 } = await request.json()

    if (!topic || !topic.trim()) {
      return NextResponse.json({ error: "Topic is required" }, { status: 400 })
    }

    const numQuestions = Math.min(Math.max(Number.parseInt(questionCount) || 5, 5), 30) // Limit between 5-30

    // Check if Gemini API key is available
    if (!process.env.GOOGLE_GEMINI_API_KEY) {
      console.log("Gemini API key not found, returning demo quiz")
      return NextResponse.json({ quiz: generateDemoQuiz(topic, numQuestions) })
    }

    try {
      // Updated API endpoint - using the correct Gemini API URL
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key=${process.env.GOOGLE_GEMINI_API_KEY}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            contents: [
              {
                parts: [
                  {
                    text: `Create a quiz about "${topic}" with exactly ${numQuestions} multiple choice questions. 

For each question:
- Provide the question text
- Provide 4 answer options (A, B, C, D)
- Indicate which option is correct (0=A, 1=B, 2=C, 3=D)

Return the response in this exact JSON format:
{
  "title": "Quiz: [Topic Name]",
  "questions": [
    {
      "question": "Question text here?",
      "options": ["Option A", "Option B", "Option C", "Option D"],
      "correctAnswer": 0
    }
  ]
}

Make sure questions are educational, varied in difficulty, and test understanding of key concepts. Include a good mix of basic, intermediate, and advanced questions.`,
                  },
                ],
              },
            ],
            generationConfig: {
              temperature: 0.7,
              topK: 40,
              topP: 0.95,
              maxOutputTokens: Math.min(4096, numQuestions * 150), // Scale tokens with question count
            },
          }),
        },
      )

      if (!response.ok) {
        console.error(`Gemini API error: ${response.status} ${response.statusText}`)
        return NextResponse.json({ quiz: generateDemoQuiz(topic, numQuestions) })
      }

      const data = await response.json()

      // Check if the response has the expected structure
      if (
        !data.candidates ||
        !data.candidates[0] ||
        !data.candidates[0].content ||
        !data.candidates[0].content.parts ||
        !data.candidates[0].content.parts[0]
      ) {
        console.error("Unexpected API response structure:", data)
        return NextResponse.json({ quiz: generateDemoQuiz(topic, numQuestions) })
      }

      const quizText = data.candidates[0].content.parts[0].text

      // Extract JSON from the response
      const jsonMatch = quizText.match(/\{[\s\S]*\}/)
      if (jsonMatch) {
        try {
          const quiz = JSON.parse(jsonMatch[0])
          return NextResponse.json({ quiz })
        } catch (parseError) {
          console.error("Error parsing quiz JSON:", parseError)
          return NextResponse.json({ quiz: generateDemoQuiz(topic, numQuestions) })
        }
      } else {
        console.error("Could not extract JSON from quiz response")
        return NextResponse.json({ quiz: generateDemoQuiz(topic, numQuestions) })
      }
    } catch (apiError) {
      console.error("Gemini API request failed:", apiError)
      return NextResponse.json({ quiz: generateDemoQuiz(topic, numQuestions) })
    }
  } catch (error) {
    console.error("Error generating quiz:", error)
    return NextResponse.json({ quiz: generateDemoQuiz("General Knowledge", 5) })
  }
}

function generateDemoQuiz(topic: string, questionCount: number) {
  const baseQuestions = [
    {
      question: `What is the primary focus of studying ${topic}?`,
      options: [
        "Understanding fundamental concepts and principles",
        "Memorizing random facts",
        "Avoiding practical applications",
        "Ignoring theoretical frameworks",
      ],
      correctAnswer: 0,
    },
    {
      question: `Which approach is most effective when learning about ${topic}?`,
      options: [
        "Passive reading only",
        "Active engagement with examples and practice",
        "Avoiding questions and discussions",
        "Studying without any structure",
      ],
      correctAnswer: 1,
    },
    {
      question: `What makes ${topic} relevant to real-world applications?`,
      options: [
        "It has no practical use",
        "It only applies to academic settings",
        "It provides tools and knowledge for solving practical problems",
        "It's purely theoretical with no applications",
      ],
      correctAnswer: 2,
    },
    {
      question: `How should you approach complex concepts in ${topic}?`,
      options: [
        "Ignore them completely",
        "Memorize without understanding",
        "Break them down into smaller, manageable parts",
        "Study them all at once without organization",
      ],
      correctAnswer: 2,
    },
    {
      question: `What is the best way to retain knowledge about ${topic}?`,
      options: [
        "Study once and never review",
        "Regular practice and spaced repetition",
        "Avoid making connections to other subjects",
        "Focus only on memorization",
      ],
      correctAnswer: 1,
    },
    {
      question: `Which study technique is most beneficial for mastering ${topic}?`,
      options: [
        "Cramming before exams",
        "Creating concept maps and visual aids",
        "Avoiding practice problems",
        "Studying in isolation",
      ],
      correctAnswer: 1,
    },
    {
      question: `What role do examples play in understanding ${topic}?`,
      options: [
        "They are unnecessary distractions",
        "They help illustrate abstract concepts",
        "They should be avoided",
        "They only confuse students",
      ],
      correctAnswer: 1,
    },
    {
      question: `How important is asking questions when studying ${topic}?`,
      options: [
        "Questions should be avoided",
        "Only basic questions are useful",
        "Critical questioning deepens understanding",
        "Questions are a waste of time",
      ],
      correctAnswer: 2,
    },
    {
      question: `What is the relationship between theory and practice in ${topic}?`,
      options: [
        "They are completely separate",
        "Theory is more important than practice",
        "Practice is more important than theory",
        "They complement and reinforce each other",
      ],
      correctAnswer: 3,
    },
    {
      question: `How should you handle difficult concepts in ${topic}?`,
      options: [
        "Skip them entirely",
        "Seek help and additional resources",
        "Memorize without understanding",
        "Give up immediately",
      ],
      correctAnswer: 1,
    },
  ]

  // Generate additional questions if needed
  const questions = []
  for (let i = 0; i < questionCount; i++) {
    if (i < baseQuestions.length) {
      questions.push(baseQuestions[i])
    } else {
      // Generate variations of existing questions
      const baseIndex = i % baseQuestions.length
      const baseQuestion = baseQuestions[baseIndex]
      questions.push({
        ...baseQuestion,
        question: `${baseQuestion.question} (Advanced)`,
      })
    }
  }

  return {
    title: `Quiz: ${topic} (${questionCount} Questions)`,
    questions: questions,
  }
}
