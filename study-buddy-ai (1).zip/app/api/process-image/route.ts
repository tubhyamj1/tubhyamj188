import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const image = formData.get("image") as File

    if (!image) {
      return NextResponse.json({ error: "No image provided" }, { status: 400 })
    }

    // Convert image to base64
    const buffer = await image.arrayBuffer()
    const base64 = Buffer.from(buffer).toString("base64")
    const mimeType = image.type

    // For demo purposes, we'll simulate OCR text extraction
    // In a real implementation, you would use Tesseract.js here
    const extractedText = `Sample extracted text from image: "${image.name}". 
    This appears to be a math problem or question that needs to be solved. 
    The image contains text that would normally be extracted using OCR technology.`

    // Get AI response using Gemini with vision capabilities
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${process.env.GOOGLE_GEMINI_API_KEY}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                {
                  text: `I have an image that contains a question or problem. Here's what I extracted from it: "${extractedText}"

Please help solve this question or problem by providing:

1. **Understanding**: What type of problem or question this appears to be
2. **Step-by-step solution**: Break down the solution process
3. **Final answer**: Provide the complete answer
4. **Key concepts**: Explain the important concepts involved
5. **Similar problems**: Suggest how to approach similar questions

If the extracted text seems unclear or incomplete, please provide general guidance on common problem-solving approaches for academic questions.`,
                },
                {
                  inline_data: {
                    mime_type: mimeType,
                    data: base64,
                  },
                },
              ],
            },
          ],
        }),
      },
    )

    if (!response.ok) {
      throw new Error(`Gemini API error: ${response.status} ${response.statusText}`)
    }

    const data = await response.json()

    // Check if the response has the expected structure
    if (
      !data.candidates ||
      !data.candidates[0] ||
      !data.candidates[0].content ||
      !data.candidates[0].content.parts ||
      !data.candidates[0].content.parts[0]
    ) {
      console.error("Unexpected API response structure:", data)

      // Fallback response
      const fallbackResponse = `I can see you've uploaded an image, but I'm having trouble processing it right now. 

Here's how I can help you with academic questions:

**For Math Problems:**
- Break down the problem into smaller steps
- Identify what you're solving for
- Apply relevant formulas or concepts
- Show your work step by step

**For Text-based Questions:**
- Read the question carefully
- Identify key terms and concepts
- Structure your answer logically
- Provide examples when helpful

**General Study Tips:**
- Take clear, well-lit photos of questions
- Make sure all text is visible and readable
- Include any relevant context or instructions

Please try uploading the image again, or feel free to type out your question directly!`

      return NextResponse.json({
        extractedText: "Unable to extract text from image at this time.",
        aiResponse: fallbackResponse,
      })
    }

    const aiResponse = data.candidates[0].content.parts[0].text

    return NextResponse.json({
      extractedText,
      aiResponse,
    })
  } catch (error) {
    console.error("Error processing image:", error)

    // Return a helpful error response instead of just failing
    return NextResponse.json({
      extractedText: "Error extracting text from image.",
      aiResponse: `I encountered an error while processing your image. Here are some things you can try:

**Troubleshooting Steps:**
1. **Check image quality**: Make sure the image is clear and well-lit
2. **File format**: Try using JPG or PNG format
3. **File size**: Ensure the image isn't too large (under 10MB)
4. **Text clarity**: Make sure any text in the image is readable

**Alternative Approaches:**
- Try taking a new photo with better lighting
- Type out your question directly if possible
- Break complex problems into smaller parts

**Common Question Types I Can Help With:**
- Math problems (algebra, calculus, geometry)
- Science questions (physics, chemistry, biology)
- Literature analysis
- History questions
- General academic topics

Feel free to try again or ask your question in text form!`,
    })
  }
}
