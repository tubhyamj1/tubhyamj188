import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { topic, length = "medium" } = await request.json()

    if (!topic || !topic.trim()) {
      return NextResponse.json({ error: "Topic is required" }, { status: 400 })
    }

    // Check if Gemini API key is available
    if (!process.env.GOOGLE_GEMINI_API_KEY) {
      console.log("Gemini API key not found, returning demo notes")
      return NextResponse.json({ notes: generateDemoNotes(topic, length) })
    }

    try {
      const lengthInstructions = getLengthInstructions(length)

      // Updated API endpoint - using the correct Gemini API URL
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key=${process.env.GOOGLE_GEMINI_API_KEY}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            contents: [
              {
                parts: [
                  {
                    text: `Create ${lengthInstructions} study notes on the topic: "${topic}". 

Please provide:
1. A clear introduction to the topic
2. Key concepts and definitions
3. Important facts and details
4. Examples where applicable
5. Summary of main points

${getLengthSpecificInstructions(length)}

Format the notes in a clear, organized manner suitable for studying. Make it detailed but easy to understand.`,
                  },
                ],
              },
            ],
            generationConfig: {
              temperature: 0.7,
              topK: 40,
              topP: 0.95,
              maxOutputTokens: getMaxTokens(length),
            },
          }),
        },
      )

      if (!response.ok) {
        console.error(`Gemini API error: ${response.status} ${response.statusText}`)
        return NextResponse.json({ notes: generateDemoNotes(topic, length) })
      }

      const data = await response.json()

      // Check if the response has the expected structure
      if (
        !data.candidates ||
        !data.candidates[0] ||
        !data.candidates[0].content ||
        !data.candidates[0].content.parts ||
        !data.candidates[0].content.parts[0]
      ) {
        console.error("Unexpected API response structure:", data)
        return NextResponse.json({ notes: generateDemoNotes(topic, length) })
      }

      const notes = data.candidates[0].content.parts[0].text
      return NextResponse.json({ notes })
    } catch (apiError) {
      console.error("Gemini API request failed:", apiError)
      return NextResponse.json({ notes: generateDemoNotes(topic, length) })
    }
  } catch (error) {
    console.error("Error in notes generation:", error)
    return NextResponse.json({ notes: generateDemoNotes("General Study Topic", "medium") })
  }
}

function getLengthInstructions(length: string): string {
  switch (length) {
    case "very-short":
      return "very concise (1-2 paragraphs)"
    case "short":
      return "brief (3-4 paragraphs)"
    case "medium":
      return "detailed (5-8 paragraphs)"
    case "long":
      return "comprehensive (10-12 paragraphs)"
    case "very-long":
      return "in-depth (15+ paragraphs)"
    default:
      return "detailed"
  }
}

function getLengthSpecificInstructions(length: string): string {
  switch (length) {
    case "very-short":
      return "Keep it concise and focus only on the most essential points. Provide a quick overview that can be read in 2-3 minutes."
    case "short":
      return "Provide a brief but informative summary. Include key concepts and main points without extensive detail."
    case "medium":
      return "Provide detailed explanations with examples. Include sufficient depth for thorough understanding."
    case "long":
      return "Provide comprehensive coverage with detailed explanations, multiple examples, and thorough analysis."
    case "very-long":
      return "Provide an in-depth, exhaustive treatment of the topic. Include detailed explanations, multiple examples, historical context, current applications, and future implications."
    default:
      return "Provide balanced coverage with appropriate detail."
  }
}

function getMaxTokens(length: string): number {
  switch (length) {
    case "very-short":
      return 512
    case "short":
      return 1024
    case "medium":
      return 2048
    case "long":
      return 3072
    case "very-long":
      return 4096
    default:
      return 2048
  }
}

function generateDemoNotes(topic: string, length: string): string {
  const baseContent = {
    "very-short": `# Study Notes: ${topic}

## Quick Overview
${topic} is an important subject that requires understanding of key concepts and practical applications. The main focus should be on grasping fundamental principles and their real-world relevance.

## Key Points
- Essential concepts and definitions
- Practical applications and examples
- Important relationships and connections

*Note: This is a very short demo overview. For detailed AI-generated notes, please configure the Gemini API.*`,

    short: `# Study Notes: ${topic}

## Introduction
${topic} encompasses fundamental concepts that are essential for academic and practical understanding. This brief guide covers the main points you need to know.

## Key Concepts
- **Definition**: Core principles and ideas in ${topic}
- **Importance**: Why this subject matters in academic and real-world contexts
- **Applications**: How these concepts are used practically

## Main Points
1. **Foundation**: Basic principles that form the groundwork
2. **Development**: How ideas have evolved and current understanding
3. **Practice**: Real-world applications and examples

## Summary
Understanding ${topic} requires grasping both theoretical concepts and practical applications. Focus on the fundamental principles and their connections to real-world scenarios.

*Note: This is a short demo summary. For detailed AI-generated notes, please configure the Gemini API.*`,

    medium: `# Study Notes: ${topic}

## 📚 Introduction
Welcome to your comprehensive study guide on **${topic}**. This guide provides detailed coverage of essential concepts, practical applications, and key insights needed for thorough understanding.

## 🔑 Key Concepts

### Definition and Scope
${topic} encompasses the fundamental principles and methodologies that form the foundation of understanding in this field. It involves both theoretical knowledge and practical applications.

### Core Principles
- **Fundamental Laws**: Basic rules and principles that govern the subject
- **Key Theories**: Important theoretical frameworks and models
- **Essential Terminology**: Critical vocabulary and definitions

## 📖 Detailed Content

### Historical Background
Understanding the development of ${topic} helps provide context for current knowledge and future directions.

### Current Applications
Modern applications of ${topic} span various fields and industries, demonstrating its practical relevance.

### Key Components
1. **Primary Elements**: Main building blocks and components
2. **Relationships**: How different parts interact and connect
3. **Systems**: Larger frameworks and organizational structures

## 💡 Examples and Applications
Real-world examples help illustrate theoretical concepts and demonstrate practical relevance.

## 📝 Study Tips
- Focus on understanding rather than memorization
- Make connections between concepts
- Practice with real examples
- Review regularly using spaced repetition

## 🎯 Summary
${topic} requires both theoretical understanding and practical application. Success comes from consistent study and active engagement with the material.

*Note: This is a medium-length demo guide. For detailed AI-generated notes, please configure the Gemini API.*`,

    long: `# Comprehensive Study Guide: ${topic}

## 📚 Introduction and Overview
This comprehensive guide provides in-depth coverage of ${topic}, designed to give you thorough understanding of both theoretical foundations and practical applications. Whether you're studying for academic purposes or professional development, this guide covers all essential aspects.

## 🎯 Learning Objectives
By the end of this study guide, you should be able to:
- Understand fundamental concepts and principles
- Apply knowledge to practical situations
- Analyze complex problems and scenarios
- Synthesize information from multiple sources

## 🔑 Fundamental Concepts

### Historical Development
The field of ${topic} has evolved significantly over time, with key developments shaping our current understanding.

### Core Definitions
Essential terminology and concepts that form the foundation of knowledge in this area.

### Theoretical Frameworks
Major theories and models that explain phenomena and guide practice in ${topic}.

## 📖 Detailed Analysis

### Primary Components
1. **Foundation Elements**: Basic building blocks and fundamental principles
2. **Advanced Concepts**: More complex ideas that build upon foundations
3. **Integration**: How different elements work together

### Methodologies and Approaches
Different ways of studying, analyzing, and applying knowledge in ${topic}.

### Current Research and Developments
Latest findings and emerging trends in the field.

## 💡 Practical Applications

### Real-World Examples
Detailed case studies and examples showing how ${topic} applies in practice.

### Problem-Solving Approaches
Systematic methods for addressing challenges and questions in this field.

### Industry Applications
How ${topic} is used across different sectors and industries.

## 🔬 Advanced Topics

### Specialized Areas
More focused aspects of ${topic} that require deeper study.

### Interdisciplinary Connections
How ${topic} relates to and integrates with other fields of study.

### Future Directions
Emerging trends and potential developments in the field.

## 📝 Study Strategies

### Effective Learning Techniques
- Active reading and note-taking
- Concept mapping and visualization
- Practice problems and applications
- Group study and discussion

### Assessment Preparation
Tips for exams, projects, and practical applications.

## 🎯 Key Takeaways
Understanding ${topic} requires dedication to both theoretical study and practical application. Success comes from consistent effort and active engagement with the material.

*Note: This is a long demo guide. For detailed AI-generated notes, please configure the Gemini API.*`,

    "very-long": `# In-Depth Study Guide: ${topic}

## 📚 Comprehensive Introduction
This exhaustive guide provides complete coverage of ${topic}, designed for serious students and professionals who need thorough, detailed understanding. This guide covers historical development, current state, practical applications, and future directions.

## 🎯 Detailed Learning Objectives
Upon completion of this comprehensive study, you will have achieved:
- Mastery of fundamental concepts and advanced principles
- Ability to analyze complex scenarios and problems
- Skills in practical application and implementation
- Understanding of research methods and current developments
- Capability to teach and explain concepts to others

## 📜 Historical Context and Development

### Origins and Early Development
The field of ${topic} has rich historical roots that inform current understanding and practice.

### Key Milestones and Breakthroughs
Major discoveries and developments that shaped the field.

### Influential Figures and Contributors
Important researchers, theorists, and practitioners who advanced knowledge.

### Evolution of Thought
How understanding and approaches have changed over time.

## 🔑 Fundamental Principles and Concepts

### Core Definitions and Terminology
Comprehensive glossary of essential terms and concepts.

### Basic Principles and Laws
Fundamental rules and principles that govern the field.

### Theoretical Frameworks
Major theories, models, and paradigms that explain phenomena.

### Conceptual Relationships
How different concepts connect and interact.

## 📖 Detailed Content Analysis

### Primary Components and Elements
In-depth examination of basic building blocks and components.

### Advanced Concepts and Theories
Complex ideas that build upon fundamental knowledge.

### Specialized Areas and Subdisciplines
Focused areas within the broader field.

### Methodological Approaches
Different ways of studying and researching in this field.

## 🔬 Research and Evidence

### Current Research Findings
Latest discoveries and research results.

### Research Methods and Techniques
How knowledge is generated and validated.

### Data Analysis and Interpretation
Methods for understanding and using research data.

### Quality and Reliability
How to evaluate the credibility of information and research.

## 💡 Practical Applications and Implementation

### Real-World Case Studies
Detailed examples of practical applications.

### Industry and Professional Applications
How ${topic} is used in various sectors.

### Problem-Solving Methodologies
Systematic approaches to addressing challenges.

### Best Practices and Guidelines
Proven methods and recommended approaches.

## 🌐 Interdisciplinary Connections

### Related Fields and Disciplines
How ${topic} connects to other areas of study.

### Cross-Disciplinary Applications
Uses that span multiple fields.

### Collaborative Approaches
Working across disciplines for better outcomes.

## 🔮 Future Directions and Emerging Trends

### Current Developments
What's happening now in the field.

### Predicted Trends
Where the field is likely to go.

### Challenges and Opportunities
Issues to address and potential for growth.

### Implications for Practice
How future developments might change applications.

## 📝 Advanced Study Strategies

### Deep Learning Techniques
Methods for achieving thorough understanding.

### Critical Analysis Skills
How to evaluate and critique information.

### Research and Investigation
Conducting your own research and analysis.

### Professional Development
Continuing education and skill building.

## 🎯 Comprehensive Summary and Integration
${topic} represents a complex and evolving field that requires dedication, critical thinking, and continuous learning. Success requires both theoretical understanding and practical application, supported by ongoing engagement with current research and developments.

## 📚 Additional Resources and References
For continued learning and deeper exploration of specific aspects of ${topic}.

*Note: This is a very long demo guide. For detailed AI-generated notes, please configure the Gemini API.*`,
  }

  return baseContent[length as keyof typeof baseContent] || baseContent.medium
}
