import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { question } = await request.json()

    if (!question || !question.trim()) {
      return NextResponse.json({ error: "Question is required" }, { status: 400 })
    }

    // Check if Gemini API key is available
    if (!process.env.GOOGLE_GEMINI_API_KEY) {
      console.log("Gemini API key not found, returning demo response")
      return NextResponse.json({ response: generateDemoResponse(question) })
    }

    try {
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key=${process.env.GOOGLE_GEMINI_API_KEY}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            contents: [
              {
                parts: [
                  {
                    text: `You are an expert tutor helping a student with their academic question. Please provide a comprehensive, educational response to this question: "${question}"

Please structure your response with:

1. **Understanding the Question**: Briefly explain what the question is asking
2. **Key Concepts**: Identify the main concepts involved
3. **Step-by-Step Solution**: Provide a detailed, easy-to-follow explanation
4. **Final Answer**: Give the complete answer if applicable
5. **Additional Tips**: Provide study tips or related concepts that might help

Make your explanation clear, educational, and appropriate for a student learning this topic. Use examples where helpful and break down complex concepts into simpler parts.`,
                  },
                ],
              },
            ],
            generationConfig: {
              temperature: 0.7,
              topK: 40,
              topP: 0.95,
              maxOutputTokens: 2048,
            },
          }),
        },
      )

      if (!response.ok) {
        throw new Error(`Gemini API error: ${response.status} ${response.statusText}`)
      }

      const data = await response.json()

      // Check if the response has the expected structure
      if (
        !data.candidates ||
        !data.candidates[0] ||
        !data.candidates[0].content ||
        !data.candidates[0].content.parts ||
        !data.candidates[0].content.parts[0]
      ) {
        console.error("Unexpected API response structure:", data)
        return NextResponse.json({ response: generateDemoResponse(question) })
      }

      const aiResponse = data.candidates[0].content.parts[0].text
      return NextResponse.json({ response: aiResponse })
    } catch (apiError) {
      console.error("Gemini API request failed:", apiError)
      return NextResponse.json({ response: generateDemoResponse(question) })
    }
  } catch (error) {
    console.error("Error processing text doubt:", error)
    return NextResponse.json({ response: generateDemoResponse("general question") })
  }
}

function generateDemoResponse(question: string): string {
  return `# 🎓 AI Tutor Response

## Understanding Your Question
You asked: "${question}"

This appears to be an academic question that I'd be happy to help you understand step by step.

## Key Concepts
The main concepts involved in this question include:
- Fundamental principles related to your topic
- Important definitions and terminology
- Practical applications and examples

## Step-by-Step Solution

### Step 1: Identify What We Know
Let's start by identifying the given information and what we're trying to find or understand.

### Step 2: Apply Relevant Concepts
We'll use the appropriate formulas, theories, or methods that apply to this type of problem.

### Step 3: Work Through the Solution
Here's how we can approach solving this systematically:

1. **Break down the problem** into smaller, manageable parts
2. **Apply the relevant concepts** we identified earlier
3. **Show our work** clearly so you can follow the reasoning
4. **Check our answer** to make sure it makes sense

## Final Answer
Based on our analysis and solution process, here's the complete answer to your question.

## Additional Tips for Success

### Study Strategies:
- **Practice regularly** with similar problems
- **Make connections** between different concepts
- **Ask questions** when something isn't clear
- **Use multiple resources** to reinforce learning

### Related Topics to Explore:
- Connected concepts that build on this knowledge
- Advanced applications of these principles
- Real-world examples where this applies

### Common Mistakes to Avoid:
- Watch out for typical errors students make with this type of question
- Double-check your work using alternative methods
- Make sure your answer makes logical sense

---

**Note**: This is a demo response. For personalized, topic-specific solutions powered by AI, please ensure the Gemini API is properly configured.

**Need More Help?** 
- Try rephrasing your question with more specific details
- Upload an image if you have a visual problem
- Break complex questions into smaller parts
- Specify your subject area for more targeted help

I'm here to help you understand and learn! Feel free to ask follow-up questions or request clarification on any part of this explanation.`
}
