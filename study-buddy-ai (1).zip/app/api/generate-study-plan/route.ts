import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { subjects, deadline, timeSlots, totalHours, studyLevel, studyGoal } = await request.json()

    if (!subjects || subjects.length === 0 || !deadline || !timeSlots || !studyLevel) {
      return NextResponse.json({ error: "All required fields must be provided" }, { status: 400 })
    }

    // Check if Gemini API key is available
    if (!process.env.GOOGLE_GEMINI_API_KEY) {
      console.log("Gemini API key not found, returning demo study plan")
      return NextResponse.json({
        studyPlan: generateDemoStudyPlan(subjects, deadline, timeSlots, totalHours, studyLevel, studyGoal),
      })
    }

    try {
      // Format subjects for the prompt
      const subjectsText = subjects
        .map((s: any) => `${s.name} (Priority: ${s.priority}, Difficulty: ${s.difficulty})`)
        .join(", ")

      // Format time slots for the prompt
      const timeSlotsText = timeSlots
        .map(
          (slot: any, index: number) =>
            `Slot ${index + 1}: ${slot.startTime} - ${slot.endTime} (${slot.duration.toFixed(1)} hours)`,
        )
        .join(", ")

      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key=${process.env.GOOGLE_GEMINI_API_KEY}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            contents: [
              {
                parts: [
                  {
                    text: `Create a comprehensive, personalized study plan with the following details:

**SUBJECTS TO STUDY:**
${subjectsText}

**STUDY SCHEDULE:**
Daily Time Slots: ${timeSlotsText}
Total Daily Study Time: ${totalHours} hours
Study Deadline: ${deadline}
Study Level: ${studyLevel}
${studyGoal ? `Study Goal: ${studyGoal}` : ""}

**REQUIREMENTS:**
1. Create a detailed daily schedule that fits within the specified time slots
2. Prioritize subjects based on their priority levels (high > medium > low)
3. Allocate more time to harder subjects
4. Include specific time blocks for each subject within the given time slots
5. Provide weekly goals and milestones
6. Include study techniques tailored to each subject's difficulty
7. Add break recommendations and wellness tips
8. Create a progress tracking system
9. Provide motivation strategies

**FORMAT THE PLAN WITH:**
- Clear daily schedules with specific time allocations
- Subject-specific study strategies
- Weekly milestones and goals
- Progress tracking methods
- Wellness and break recommendations
- Motivation and productivity tips

Make the plan practical, achievable, and optimized for the student's success within their available time slots.`,
                  },
                ],
              },
            ],
            generationConfig: {
              temperature: 0.7,
              topK: 40,
              topP: 0.95,
              maxOutputTokens: 3072,
            },
          }),
        },
      )

      if (!response.ok) {
        console.error(`Gemini API error: ${response.status} ${response.statusText}`)
        return NextResponse.json({
          studyPlan: generateDemoStudyPlan(subjects, deadline, timeSlots, totalHours, studyLevel, studyGoal),
        })
      }

      const data = await response.json()

      if (
        !data.candidates ||
        !data.candidates[0] ||
        !data.candidates[0].content ||
        !data.candidates[0].content.parts ||
        !data.candidates[0].content.parts[0]
      ) {
        console.error("Unexpected API response structure:", data)
        return NextResponse.json({
          studyPlan: generateDemoStudyPlan(subjects, deadline, timeSlots, totalHours, studyLevel, studyGoal),
        })
      }

      const studyPlan = data.candidates[0].content.parts[0].text
      return NextResponse.json({ studyPlan })
    } catch (apiError) {
      console.error("Gemini API request failed:", apiError)
      return NextResponse.json({
        studyPlan: generateDemoStudyPlan(subjects, deadline, timeSlots, totalHours, studyLevel, studyGoal),
      })
    }
  } catch (error) {
    console.error("Error generating study plan:", error)
    return NextResponse.json({
      studyPlan: generateDemoStudyPlan(
        [{ name: "General Studies", priority: "medium", difficulty: "medium" }],
        "Next Month",
        [{ startTime: "16:00", endTime: "21:00", duration: 5 }],
        5,
        "undergraduate",
        "",
      ),
    })
  }
}

function generateDemoStudyPlan(
  subjects: any[],
  deadline: string,
  timeSlots: any[],
  totalHours: number,
  studyLevel: string,
  studyGoal: string,
): string {
  const subjectsText = subjects.map((s) => s.name).join(", ")
  const timeSlotsText = timeSlots
    .map((slot, index) => `${slot.startTime} - ${slot.endTime} (${slot.duration.toFixed(1)}h)`)
    .join(", ")

  return `# 🎯 AI-Optimized Study Plan

## 📊 Study Overview
- **Subjects**: ${subjectsText}
- **Daily Study Time**: ${totalHours} hours
- **Time Slots**: ${timeSlotsText}
- **Deadline**: ${deadline}
- **Level**: ${studyLevel}
${studyGoal ? `- **Goal**: ${studyGoal}` : ""}

## 📅 Daily Schedule Template

### Time Slot Breakdown:
${timeSlots
  .map((slot, index) => {
    const duration = slot.duration
    const subjectTime = duration / subjects.length
    return `
**Slot ${index + 1}: ${slot.startTime} - ${slot.endTime}**
${subjects
  .map((subject, subIndex) => {
    const startMinutes = Math.floor(subIndex * subjectTime * 60)
    const endMinutes = Math.floor((subIndex + 1) * subjectTime * 60)
    const startTime = new Date(`2000-01-01T${slot.startTime}`)
    startTime.setMinutes(startTime.getMinutes() + startMinutes)
    const endTime = new Date(`2000-01-01T${slot.startTime}`)
    endTime.setMinutes(endTime.getMinutes() + endMinutes)

    return `• ${startTime.toLocaleTimeString("en-US", { hour12: false, hour: "2-digit", minute: "2-digit" })} - ${endTime.toLocaleTimeString("en-US", { hour12: false, hour: "2-digit", minute: "2-digit" })}: ${subject.name} (${subject.priority} priority, ${subject.difficulty} level)`
  })
  .join("\n")}
`
  })
  .join("\n")}

## 🎯 Subject-Specific Strategies

${subjects
  .map(
    (subject) => `
### ${subject.name}
- **Priority Level**: ${subject.priority.toUpperCase()}
- **Difficulty**: ${subject.difficulty.toUpperCase()}
- **Recommended Approach**: ${
      subject.difficulty === "hard"
        ? "Break into smaller chunks, use active recall, seek additional resources"
        : subject.difficulty === "medium"
          ? "Balanced study with practice problems and review"
          : "Focus on understanding key concepts and regular review"
    }
- **Study Techniques**: ${
      subject.priority === "high"
        ? "Daily practice, intensive review, extra time allocation"
        : subject.priority === "medium"
          ? "Regular study sessions, consistent practice"
          : "Maintenance review, lighter focus"
    }
`,
  )
  .join("")}

## 📈 Weekly Milestones

### Week 1: Foundation Building
- [ ] Complete initial assessment of all subjects
- [ ] Create detailed notes for high-priority subjects
- [ ] Establish study routine within time slots
- [ ] Identify challenging areas needing extra attention

### Week 2: Skill Development
- [ ] Practice problems for medium/hard difficulty subjects
- [ ] Review and reinforce Week 1 concepts
- [ ] Seek help for difficult topics
- [ ] Complete first progress assessment

### Week 3: Application & Practice
- [ ] Apply concepts through practical exercises
- [ ] Focus extra time on high-priority subjects
- [ ] Complete practice tests or assignments
- [ ] Refine study techniques based on progress

### Week 4: Mastery & Review
- [ ] Comprehensive review of all subjects
- [ ] Intensive practice for challenging areas
- [ ] Final preparations and confidence building
- [ ] Complete final assessment

## 🧠 Optimized Study Techniques

### For High-Priority Subjects:
1. **Active Recall**: Test yourself regularly without looking at notes
2. **Spaced Repetition**: Review at increasing intervals
3. **Practice Testing**: Regular quizzes and mock exams
4. **Teaching Method**: Explain concepts to others or yourself

### For Hard Difficulty Subjects:
1. **Chunking**: Break complex topics into smaller parts
2. **Visual Learning**: Use diagrams, charts, and mind maps
3. **Multiple Resources**: Use various textbooks and online materials
4. **Peer Study**: Form study groups for difficult concepts

## ⏰ Time Management & Breaks

### Within Each Time Slot:
- **25-minute focused study blocks** (Pomodoro Technique)
- **5-minute breaks** between blocks
- **15-minute break** every 2 hours
- **Stay hydrated** and maintain good posture

### Daily Wellness:
- 7-8 hours of quality sleep
- Regular meals and healthy snacks
- 30 minutes of physical activity
- Stress management and relaxation

## 📊 Progress Tracking System

### Daily Tracking:
- [ ] Hours studied per subject
- [ ] Topics covered and understood
- [ ] Difficulty level (1-10 scale)
- [ ] Energy and focus level
- [ ] Key insights and breakthroughs

### Weekly Review:
- [ ] Goals achieved vs. planned
- [ ] Areas needing more attention
- [ ] Study technique effectiveness
- [ ] Schedule adjustments needed
- [ ] Overall confidence level

## 💪 Motivation & Success Strategies

### Stay Motivated:
1. **Clear Goals**: Keep your study goal in mind: ${studyGoal || "Academic success"}
2. **Reward System**: Celebrate completing daily/weekly goals
3. **Progress Visualization**: Track your improvement over time
4. **Positive Environment**: Create a dedicated, distraction-free study space
5. **Support Network**: Connect with study partners or mentors

### Overcome Challenges:
- **Feeling Overwhelmed**: Focus on one subject at a time
- **Lack of Motivation**: Remember your goals and progress made
- **Difficult Concepts**: Break them down, seek help, use multiple resources
- **Time Constraints**: Prioritize high-impact activities
- **Fatigue**: Ensure adequate rest and breaks

## 🚀 Success Tips

1. **Consistency is Key**: Stick to your time slots daily
2. **Quality over Quantity**: Focus during study time
3. **Adapt as Needed**: Adjust the plan based on progress
4. **Stay Organized**: Keep materials and notes well-organized
5. **Regular Assessment**: Evaluate and improve your methods

---

**Remember**: This AI-optimized plan is designed specifically for your subjects, time slots, and goals. Stay flexible and adjust as needed while maintaining consistency in your study routine!

*Note: This is a demo study plan. For AI-generated, fully personalized plans, please ensure the Gemini API is properly configured.*`
}
