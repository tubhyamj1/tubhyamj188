"use client"

import Dashboard from "@/components/dashboard"

export default function StudyBuddyAI() {
  return <Dashboard />
}
