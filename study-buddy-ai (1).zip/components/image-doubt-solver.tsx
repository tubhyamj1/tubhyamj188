"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { ImageIcon, Upload, Loader2, Camera, AlertCircle, ArrowLeft, HelpCircle } from "lucide-react"
import { Label } from "@/components/ui/label"

interface ImageDoubtSolverProps {
  onBackToDashboard?: () => void
}

export default function ImageDoubtSolver({ onBackToDashboard }: ImageDoubtSolverProps) {
  const [selectedImage, setSelectedImage] = useState<File | null>(null)
  const [imagePreview, setImagePreview] = useState<string>("")
  const [extractedText, setExtractedText] = useState("")
  const [aiResponse, setAiResponse] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [stage, setStage] = useState<"upload" | "processing" | "result">("upload")
  const fileInputRef = useRef<HTMLInputElement>(null)

  const [textDoubt, setTextDoubt] = useState("")
  const [textResponse, setTextResponse] = useState("")
  const [textLoading, setTextLoading] = useState(false)
  const [activeMode, setActiveMode] = useState<"image" | "text">("image")

  const handleImageSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      // Check file size (limit to 10MB)
      if (file.size > 10 * 1024 * 1024) {
        setError("File size too large. Please choose an image under 10MB.")
        return
      }

      // Check file type
      if (!file.type.startsWith("image/")) {
        setError("Please select a valid image file.")
        return
      }

      setSelectedImage(file)
      setError("")
      const reader = new FileReader()
      reader.onload = (e) => {
        setImagePreview(e.target?.result as string)
      }
      reader.readAsDataURL(file)
      setStage("upload")
    }
  }

  const processImage = async () => {
    if (!selectedImage) return

    setLoading(true)
    setStage("processing")
    setError("")

    try {
      // Create FormData to send the image
      const formData = new FormData()
      formData.append("image", selectedImage)

      const response = await fetch("/api/process-image", {
        method: "POST",
        body: formData,
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const data = await response.json()

      if (data.error) {
        throw new Error(data.error)
      }

      setExtractedText(data.extractedText || "No text could be extracted from the image.")
      setAiResponse(data.aiResponse || "No response generated.")
      setStage("result")
    } catch (error) {
      console.error("Error processing image:", error)
      setError(error instanceof Error ? error.message : "An unexpected error occurred")
      setAiResponse(`Sorry, I encountered an error while processing your image. 

**What you can try:**
1. Check your internet connection
2. Try a different image format (JPG or PNG)
3. Ensure the image is clear and well-lit
4. Make sure the file size is under 10MB

**Alternative:** You can also type your question directly, and I'll be happy to help solve it!`)
      setStage("result")
    } finally {
      setLoading(false)
    }
  }

  const resetUpload = () => {
    setSelectedImage(null)
    setImagePreview("")
    setExtractedText("")
    setAiResponse("")
    setError("")
    setStage("upload")
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const solveTextDoubt = async () => {
    if (!textDoubt.trim()) return

    setTextLoading(true)
    setTextResponse("")

    try {
      const response = await fetch("/api/solve-text-doubt", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ question: textDoubt }),
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const data = await response.json()

      if (data.error) {
        throw new Error(data.error)
      }

      setTextResponse(data.response || "No response generated.")
    } catch (error) {
      console.error("Error solving text doubt:", error)
      setTextResponse(`Sorry, I encountered an error while processing your question.

**What you can try:**
1. Check your internet connection
2. Rephrase your question more clearly
3. Break complex questions into smaller parts
4. Try asking about specific concepts

**Alternative:** You can also upload an image of your question, and I'll be happy to help solve it!`)
    } finally {
      setTextLoading(false)
    }
  }

  return (
    <div className="max-w-4xl mx-auto">
      {/* Back to Dashboard Button */}
      {onBackToDashboard && (
        <div className="mb-6">
          <Button variant="ghost" onClick={onBackToDashboard} className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back to Dashboard
          </Button>
        </div>
      )}

      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <ImageIcon className="h-6 w-6 text-indigo-600" />
            <CardTitle>Doubt Solver</CardTitle>
          </div>
          <CardDescription>Upload an image or type your question to get instant AI-powered solutions</CardDescription>

          {/* Mode Selection */}
          <div className="flex gap-2 mt-4">
            <Button
              variant={activeMode === "image" ? "default" : "outline"}
              onClick={() => setActiveMode("image")}
              className="flex-1"
            >
              <ImageIcon className="h-4 w-4 mr-2" />
              Image Upload
            </Button>
            <Button
              variant={activeMode === "text" ? "default" : "outline"}
              onClick={() => setActiveMode("text")}
              className="flex-1"
            >
              <HelpCircle className="h-4 w-4 mr-2" />
              Type Question
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {error && (
            <Card className="bg-red-50 border-red-200">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 text-red-800">
                  <AlertCircle className="h-4 w-4" />
                  <span className="font-semibold">Error:</span>
                </div>
                <p className="text-red-700 text-sm mt-1">{error}</p>
              </CardContent>
            </Card>
          )}

          {activeMode === "text" && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="textDoubt">Type your question or doubt</Label>
                <Textarea
                  id="textDoubt"
                  placeholder="Enter your question here... (e.g., How do I solve quadratic equations? What is photosynthesis? Explain Newton's laws of motion)"
                  value={textDoubt}
                  onChange={(e) => setTextDoubt(e.target.value)}
                  className="mt-1 min-h-[120px]"
                />
              </div>

              <Button onClick={solveTextDoubt} disabled={textLoading || !textDoubt.trim()} className="w-full">
                {textLoading ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Solving your doubt...
                  </>
                ) : (
                  <>
                    <HelpCircle className="h-4 w-4 mr-2" />
                    Solve My Doubt
                  </>
                )}
              </Button>

              {textResponse && (
                <Card className="bg-blue-50 mt-6">
                  <CardHeader>
                    <CardTitle className="text-lg text-blue-900">AI Solution</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Textarea
                      value={textResponse}
                      readOnly
                      className="min-h-[300px] bg-white"
                      placeholder="AI-generated solution will appear here..."
                    />
                    <div className="mt-4 flex gap-3">
                      <Button
                        variant="outline"
                        onClick={() => navigator.clipboard.writeText(textResponse)}
                        className="flex-1"
                      >
                        Copy Solution
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => {
                          const element = document.createElement("a")
                          const file = new Blob([textResponse], { type: "text/plain" })
                          element.href = URL.createObjectURL(file)
                          element.download = "doubt-solution.txt"
                          document.body.appendChild(element)
                          element.click()
                          document.body.removeChild(element)
                        }}
                        className="flex-1"
                      >
                        Download Solution
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          )}

          {activeMode === "image" && stage === "upload" && (
            <>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageSelect}
                  className="hidden"
                  ref={fileInputRef}
                />

                {!imagePreview ? (
                  <div className="space-y-4">
                    <Camera className="h-16 w-16 mx-auto text-gray-400" />
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">Upload an Image</h3>
                      <p className="text-gray-600 mb-4">
                        Take a photo or upload an image containing questions, problems, or text you need help with
                      </p>
                      <Button onClick={() => fileInputRef.current?.click()}>
                        <Upload className="h-4 w-4 mr-2" />
                        Choose Image
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <img
                      src={imagePreview || "/placeholder.svg"}
                      alt="Selected"
                      className="max-w-full h-auto max-h-64 mx-auto rounded-lg"
                    />
                    <div className="flex gap-4 justify-center">
                      <Button onClick={processImage} disabled={loading}>
                        {loading ? (
                          <>
                            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                            Processing...
                          </>
                        ) : (
                          "Solve This Image"
                        )}
                      </Button>
                      <Button variant="outline" onClick={resetUpload}>
                        Choose Different Image
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </>
          )}

          {stage === "processing" && (
            <div className="text-center py-12">
              <Loader2 className="h-12 w-12 mx-auto animate-spin text-indigo-600 mb-4" />
              <h3 className="text-lg font-semibold mb-2">Processing Your Image</h3>
              <p className="text-gray-600">Analyzing the image and generating solution...</p>
            </div>
          )}

          {stage === "result" && (
            <div className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold mb-3">Your Image:</h3>
                  <img
                    src={imagePreview || "/placeholder.svg"}
                    alt="Processed"
                    className="w-full h-auto rounded-lg border"
                  />
                </div>
                <div>
                  <h3 className="font-semibold mb-3">Extracted Text:</h3>
                  <Textarea
                    value={extractedText}
                    readOnly
                    className="min-h-[200px] bg-gray-50"
                    placeholder="Text extracted from image will appear here..."
                  />
                </div>
              </div>

              <Card className="bg-blue-50">
                <CardHeader>
                  <CardTitle className="text-lg text-blue-900">AI Solution</CardTitle>
                </CardHeader>
                <CardContent>
                  <Textarea
                    value={aiResponse}
                    readOnly
                    className="min-h-[300px] bg-white"
                    placeholder="AI-generated solution will appear here..."
                  />
                </CardContent>
              </Card>

              <div className="flex justify-center gap-4">
                <Button onClick={resetUpload}>Solve Another Image</Button>
                {onBackToDashboard && (
                  <Button variant="outline" onClick={onBackToDashboard}>
                    Back to Dashboard
                  </Button>
                )}
              </div>
            </div>
          )}

          <Card className="bg-yellow-50">
            <CardContent className="p-4">
              <h4 className="font-semibold text-yellow-900 mb-2">💡 Tips for Better Results</h4>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <h5 className="font-medium text-yellow-800 mb-1">📸 Image Upload:</h5>
                  <ul className="text-yellow-800 text-sm space-y-1">
                    <li>• Ensure the image is clear and well-lit</li>
                    <li>• Make sure text is readable and not blurry</li>
                    <li>• Include the complete question or problem</li>
                    <li>• Use JPG or PNG format, under 10MB</li>
                  </ul>
                </div>
                <div>
                  <h5 className="font-medium text-yellow-800 mb-1">✍️ Text Questions:</h5>
                  <ul className="text-yellow-800 text-sm space-y-1">
                    <li>• Be specific and clear in your question</li>
                    <li>• Include relevant context or background</li>
                    <li>• Break complex problems into parts</li>
                    <li>• Mention your subject or topic area</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </CardContent>
      </Card>
    </div>
  )
}
