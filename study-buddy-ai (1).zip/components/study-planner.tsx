"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Calendar, Loader2, Clock, ArrowLeft, Plus, X, BookOpen, Target } from "lucide-react"

interface StudyPlannerProps {
  onBackToDashboard?: () => void
}

interface Subject {
  id: string
  name: string
  priority: "high" | "medium" | "low"
  difficulty: "easy" | "medium" | "hard"
}

interface TimeSlot {
  startTime: string
  endTime: string
  duration: number
}

interface ScheduleItem {
  time: string
  subject: string
  priority: string
  difficulty: string
  duration: number
}

export default function StudyPlanner({ onBackToDashboard }: StudyPlannerProps) {
  const [subjects, setSubjects] = useState<Subject[]>([])
  const [newSubject, setNewSubject] = useState("")
  const [deadline, setDeadline] = useState("")
  const [timeSlots, setTimeSlots] = useState<TimeSlot[]>([{ startTime: "", endTime: "", duration: 0 }])
  const [studyLevel, setStudyLevel] = useState("")
  const [studyGoal, setStudyGoal] = useState("")
  const [studyPlan, setStudyPlan] = useState("")
  const [scheduleChart, setScheduleChart] = useState<ScheduleItem[]>([])
  const [loading, setLoading] = useState(false)

  const addSubject = () => {
    if (!newSubject.trim()) return

    const subject: Subject = {
      id: Date.now().toString(),
      name: newSubject.trim(),
      priority: "medium",
      difficulty: "medium",
    }

    setSubjects([...subjects, subject])
    setNewSubject("")
  }

  const removeSubject = (id: string) => {
    setSubjects(subjects.filter((s) => s.id !== id))
  }

  const updateSubject = (id: string, field: keyof Subject, value: string) => {
    setSubjects(subjects.map((s) => (s.id === id ? { ...s, [field]: value } : s)))
  }

  const addTimeSlot = () => {
    setTimeSlots([...timeSlots, { startTime: "", endTime: "", duration: 0 }])
  }

  const removeTimeSlot = (index: number) => {
    if (timeSlots.length > 1) {
      setTimeSlots(timeSlots.filter((_, i) => i !== index))
    }
  }

  const updateTimeSlot = (index: number, field: keyof TimeSlot, value: string) => {
    const newSlots = [...timeSlots]
    if (field === "startTime" || field === "endTime") {
      newSlots[index][field] = value
      // Calculate duration when both times are set
      if (newSlots[index].startTime && newSlots[index].endTime) {
        const start = new Date(`2000-01-01T${newSlots[index].startTime}`)
        const end = new Date(`2000-01-01T${newSlots[index].endTime}`)
        const duration = (end.getTime() - start.getTime()) / (1000 * 60 * 60) // hours
        newSlots[index].duration = Math.max(0, duration)
      }
    }
    setTimeSlots(newSlots)
  }

  const getTotalStudyHours = () => {
    return timeSlots.reduce((total, slot) => total + slot.duration, 0)
  }

  const generateScheduleChart = () => {
    const chart: ScheduleItem[] = []

    timeSlots.forEach((slot, slotIndex) => {
      if (slot.startTime && slot.endTime && subjects.length > 0) {
        const slotDuration = slot.duration
        const timePerSubject = slotDuration / subjects.length

        // Sort subjects by priority (high -> medium -> low)
        const sortedSubjects = [...subjects].sort((a, b) => {
          const priorityOrder = { high: 3, medium: 2, low: 1 }
          return priorityOrder[b.priority] - priorityOrder[a.priority]
        })

        sortedSubjects.forEach((subject, subjectIndex) => {
          const startMinutes = Math.floor(subjectIndex * timePerSubject * 60)
          const endMinutes = Math.floor((subjectIndex + 1) * timePerSubject * 60)

          const startTime = new Date(`2000-01-01T${slot.startTime}`)
          startTime.setMinutes(startTime.getMinutes() + startMinutes)

          const endTime = new Date(`2000-01-01T${slot.startTime}`)
          endTime.setMinutes(endTime.getMinutes() + endMinutes)

          chart.push({
            time: `${startTime.toLocaleTimeString("en-US", { hour12: false, hour: "2-digit", minute: "2-digit" })} - ${endTime.toLocaleTimeString("en-US", { hour12: false, hour: "2-digit", minute: "2-digit" })}`,
            subject: subject.name,
            priority: subject.priority,
            difficulty: subject.difficulty,
            duration: timePerSubject,
          })
        })
      }
    })

    return chart
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      case "low":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "hard":
        return "bg-purple-100 text-purple-800"
      case "medium":
        return "bg-blue-100 text-blue-800"
      case "easy":
        return "bg-emerald-100 text-emerald-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const generateStudyPlan = async () => {
    if (
      subjects.length === 0 ||
      !deadline ||
      timeSlots.some((slot) => !slot.startTime || !slot.endTime) ||
      !studyLevel
    ) {
      return
    }

    setLoading(true)

    // Generate schedule chart
    const chart = generateScheduleChart()
    setScheduleChart(chart)

    try {
      const response = await fetch("/api/generate-study-plan", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          subjects: subjects.map((s) => ({
            name: s.name,
            priority: s.priority,
            difficulty: s.difficulty,
          })),
          deadline,
          timeSlots,
          totalHours: getTotalStudyHours(),
          studyLevel,
          studyGoal,
        }),
      })

      const data = await response.json()
      setStudyPlan(data.studyPlan)
    } catch (error) {
      console.error("Error generating study plan:", error)
      setStudyPlan("Error generating study plan. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Back to Dashboard Button */}
      {onBackToDashboard && (
        <div className="mb-6">
          <Button variant="ghost" onClick={onBackToDashboard} className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back to Dashboard
          </Button>
        </div>
      )}

      {/* Classic Header */}
      <div className="text-center space-y-2 mb-8">
        <h1 className="text-3xl font-bold text-gray-900">AI Study Planner</h1>
        <p className="text-gray-600 max-w-2xl mx-auto">
          Create your personalized study schedule with AI-powered optimization
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Left Column - Input Section */}
        <div className="space-y-6">
          {/* Subjects Section */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="h-5 w-5" />
                Study Subjects
              </CardTitle>
              <CardDescription>Add and configure your subjects</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Add Subject */}
              <div className="flex gap-2">
                <Input
                  placeholder="Enter subject name"
                  value={newSubject}
                  onChange={(e) => setNewSubject(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && addSubject()}
                  className="flex-1"
                />
                <Button onClick={addSubject}>
                  <Plus className="h-4 w-4" />
                </Button>
              </div>

              {/* Subjects List */}
              <div className="space-y-3">
                {subjects.map((subject) => (
                  <div key={subject.id} className="p-3 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">{subject.name}</h4>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeSubject(subject.id)}
                        className="text-red-500 hover:text-red-700"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="grid grid-cols-2 gap-2 mb-2">
                      <div>
                        <Label className="text-xs">Priority</Label>
                        <Select
                          value={subject.priority}
                          onValueChange={(value) => updateSubject(subject.id, "priority", value)}
                        >
                          <SelectTrigger className="h-8">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="high">High</SelectItem>
                            <SelectItem value="medium">Medium</SelectItem>
                            <SelectItem value="low">Low</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label className="text-xs">Difficulty</Label>
                        <Select
                          value={subject.difficulty}
                          onValueChange={(value) => updateSubject(subject.id, "difficulty", value)}
                        >
                          <SelectTrigger className="h-8">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="easy">Easy</SelectItem>
                            <SelectItem value="medium">Medium</SelectItem>
                            <SelectItem value="hard">Hard</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Badge className={getPriorityColor(subject.priority)}>{subject.priority}</Badge>
                      <Badge className={getDifficultyColor(subject.difficulty)}>{subject.difficulty}</Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Time Slots Section */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Study Time Slots
              </CardTitle>
              <CardDescription>Define your available study hours</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {timeSlots.map((slot, index) => (
                <div key={index} className="p-3 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium">Time Slot {index + 1}</h4>
                    {timeSlots.length > 1 && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeTimeSlot(index)}
                        className="text-red-500 hover:text-red-700"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <Label className="text-xs">Start</Label>
                      <Input
                        type="time"
                        value={slot.startTime}
                        onChange={(e) => updateTimeSlot(index, "startTime", e.target.value)}
                        className="h-8"
                      />
                    </div>
                    <div>
                      <Label className="text-xs">End</Label>
                      <Input
                        type="time"
                        value={slot.endTime}
                        onChange={(e) => updateTimeSlot(index, "endTime", e.target.value)}
                        className="h-8"
                      />
                    </div>
                    <div>
                      <Label className="text-xs">Duration</Label>
                      <div className="h-8 px-2 py-1 bg-gray-50 border rounded text-sm flex items-center">
                        {slot.duration > 0 ? `${slot.duration.toFixed(1)}h` : "0h"}
                      </div>
                    </div>
                  </div>
                </div>
              ))}

              <Button onClick={addTimeSlot} variant="outline" className="w-full bg-transparent">
                <Plus className="h-4 w-4 mr-2" />
                Add Time Slot
              </Button>

              {getTotalStudyHours() > 0 && (
                <div className="p-3 bg-blue-50 rounded-lg text-center">
                  <div className="text-xl font-bold text-blue-600">{getTotalStudyHours().toFixed(1)} hours</div>
                  <div className="text-sm text-blue-600">Total daily study time</div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Right Column - Configuration & Results */}
        <div className="space-y-6">
          {/* Study Configuration */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Study Configuration
              </CardTitle>
              <CardDescription>Set your study preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="deadline">Study Deadline</Label>
                <Input
                  id="deadline"
                  type="date"
                  value={deadline}
                  onChange={(e) => setDeadline(e.target.value)}
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="studyLevel">Study Level</Label>
                <Select value={studyLevel} onValueChange={setStudyLevel}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select your level" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="high-school">High School</SelectItem>
                    <SelectItem value="undergraduate">Undergraduate</SelectItem>
                    <SelectItem value="graduate">Graduate</SelectItem>
                    <SelectItem value="professional">Professional</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="studyGoal">Study Goal (Optional)</Label>
                <Textarea
                  id="studyGoal"
                  placeholder="e.g., Prepare for final exams..."
                  value={studyGoal}
                  onChange={(e) => setStudyGoal(e.target.value)}
                  className="mt-1 min-h-[80px]"
                />
              </div>

              <Button
                onClick={generateStudyPlan}
                disabled={loading || subjects.length === 0 || !deadline || !studyLevel || getTotalStudyHours() === 0}
                className="w-full"
              >
                {loading ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Creating Study Plan...
                  </>
                ) : (
                  <>
                    <Calendar className="h-4 w-4 mr-2" />
                    Generate Study Plan
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Study Overview */}
          {subjects.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Study Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div className="text-center p-3 bg-gray-50 rounded">
                    <div className="text-2xl font-bold">{subjects.length}</div>
                    <div className="text-sm text-gray-600">Subjects</div>
                  </div>
                  <div className="text-center p-3 bg-gray-50 rounded">
                    <div className="text-2xl font-bold">{getTotalStudyHours().toFixed(1)}h</div>
                    <div className="text-sm text-gray-600">Daily Hours</div>
                  </div>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>High Priority:</span>
                    <span>{subjects.filter((s) => s.priority === "high").length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Hard Difficulty:</span>
                    <span>{subjects.filter((s) => s.difficulty === "hard").length}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Schedule Chart */}
      {scheduleChart.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Daily Study Schedule Chart
            </CardTitle>
            <CardDescription>Your optimized daily study timetable</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse border border-gray-300">
                <thead>
                  <tr className="bg-gray-50">
                    <th className="border border-gray-300 px-4 py-2 text-left font-semibold">Time</th>
                    <th className="border border-gray-300 px-4 py-2 text-left font-semibold">Subject</th>
                    <th className="border border-gray-300 px-4 py-2 text-left font-semibold">Priority</th>
                    <th className="border border-gray-300 px-4 py-2 text-left font-semibold">Difficulty</th>
                    <th className="border border-gray-300 px-4 py-2 text-left font-semibold">Duration</th>
                  </tr>
                </thead>
                <tbody>
                  {scheduleChart.map((item, index) => (
                    <tr key={index} className={index % 2 === 0 ? "bg-white" : "bg-gray-50"}>
                      <td className="border border-gray-300 px-4 py-2 font-mono text-sm">{item.time}</td>
                      <td className="border border-gray-300 px-4 py-2 font-medium">{item.subject}</td>
                      <td className="border border-gray-300 px-4 py-2">
                        <Badge className={getPriorityColor(item.priority)}>{item.priority}</Badge>
                      </td>
                      <td className="border border-gray-300 px-4 py-2">
                        <Badge className={getDifficultyColor(item.difficulty)}>{item.difficulty}</Badge>
                      </td>
                      <td className="border border-gray-300 px-4 py-2">{item.duration.toFixed(1)}h</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Study Plan Results */}
      {studyPlan && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Study Plan Details</CardTitle>
            <CardDescription>AI-generated study recommendations</CardDescription>
          </CardHeader>
          <CardContent>
            <Textarea value={studyPlan} readOnly className="min-h-[400px] bg-gray-50 font-mono text-sm" />
            <div className="mt-4 flex gap-3">
              <Button variant="outline" onClick={() => navigator.clipboard.writeText(studyPlan)} className="flex-1">
                Copy Study Plan
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  const element = document.createElement("a")
                  const file = new Blob([studyPlan], { type: "text/plain" })
                  element.href = URL.createObjectURL(file)
                  element.download = "study-plan.txt"
                  document.body.appendChild(element)
                  element.click()
                  document.body.removeChild(element)
                }}
                className="flex-1"
              >
                Download Plan
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
