"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BookOpen, Loader2, ArrowLeft, HelpCircle, Copy, Download } from "lucide-react"

interface NotesGeneratorProps {
  onBackToDashboard?: () => void
}

export default function NotesGenerator({ onBackToDashboard }: NotesGeneratorProps) {
  const [topic, setTopic] = useState("")
  const [noteLength, setNoteLength] = useState("medium")
  const [notes, setNotes] = useState("")
  const [questions, setQuestions] = useState("")
  const [loading, setLoading] = useState(false)
  const [questionLoading, setQuestionLoading] = useState(false)
  const [activeTab, setActiveTab] = useState("notes")

  const generateNotes = async () => {
    if (!topic.trim()) return

    setLoading(true)
    try {
      const response = await fetch("/api/generate-notes", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ topic, length: noteLength }),
      })

      const data = await response.json()
      setNotes(data.notes)
      setActiveTab("notes")
    } catch (error) {
      console.error("Error generating notes:", error)
      setNotes("Error generating notes. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  const generateQuestions = async () => {
    if (!topic.trim()) return

    setQuestionLoading(true)
    try {
      const response = await fetch("/api/generate-questions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ topic }),
      })

      const data = await response.json()
      setQuestions(data.questions)
      setActiveTab("questions")
    } catch (error) {
      console.error("Error generating questions:", error)
      setQuestions("Error generating questions. Please try again.")
    } finally {
      setQuestionLoading(false)
    }
  }

  const generateBoth = async () => {
    if (!topic.trim()) return

    // Generate notes first
    await generateNotes()
    // Then generate questions
    await generateQuestions()
  }

  const copyToClipboard = (content: string) => {
    navigator.clipboard.writeText(content)
  }

  const downloadContent = (content: string, filename: string) => {
    const element = document.createElement("a")
    const file = new Blob([content], { type: "text/plain" })
    element.href = URL.createObjectURL(file)
    element.download = `${filename}-${topic.replace(/\s+/g, "-").toLowerCase()}.txt`
    document.body.appendChild(element)
    element.click()
    document.body.removeChild(element)
  }

  const getLengthDescription = (length: string) => {
    switch (length) {
      case "very-short":
        return "Quick overview (1-2 paragraphs)"
      case "short":
        return "Brief summary (3-4 paragraphs)"
      case "medium":
        return "Detailed notes (5-8 paragraphs)"
      case "long":
        return "Comprehensive guide (10+ paragraphs)"
      case "very-long":
        return "In-depth analysis (15+ paragraphs)"
      default:
        return "Standard length"
    }
  }

  return (
    <div className="max-w-6xl mx-auto">
      {/* Back to Dashboard Button */}
      {onBackToDashboard && (
        <div className="mb-6">
          <Button variant="ghost" onClick={onBackToDashboard} className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back to Dashboard
          </Button>
        </div>
      )}

      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <BookOpen className="h-6 w-6 text-blue-600" />
            <CardTitle>AI Notes & Questions Generator</CardTitle>
          </div>
          <CardDescription>
            Generate comprehensive study notes and practice questions on any topic with customizable length options
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Input Section */}
          <div className="grid md:grid-cols-3 gap-4">
            <div className="md:col-span-2">
              <Label htmlFor="topic">Study Topic</Label>
              <Input
                id="topic"
                placeholder="Enter a topic (e.g., Photosynthesis, World War 2, Calculus)"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && generateNotes()}
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="length">Note Length</Label>
              <Select value={noteLength} onValueChange={setNoteLength}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Select length" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="very-short">Very Short</SelectItem>
                  <SelectItem value="short">Short</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="long">Long</SelectItem>
                  <SelectItem value="very-long">Very Long</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-gray-500 mt-1">{getLengthDescription(noteLength)}</p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap gap-3">
            <Button onClick={generateNotes} disabled={loading || !topic.trim()}>
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Generating Notes...
                </>
              ) : (
                <>
                  <BookOpen className="h-4 w-4 mr-2" />
                  Generate Notes
                </>
              )}
            </Button>

            <Button onClick={generateQuestions} disabled={questionLoading || !topic.trim()} variant="outline">
              {questionLoading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Generating Questions...
                </>
              ) : (
                <>
                  <HelpCircle className="h-4 w-4 mr-2" />
                  Generate Questions
                </>
              )}
            </Button>

            <Button onClick={generateBoth} disabled={loading || questionLoading || !topic.trim()} variant="secondary">
              {loading || questionLoading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Generating Both...
                </>
              ) : (
                "Generate Both"
              )}
            </Button>
          </div>

          {/* Results Section */}
          {(notes || questions) && (
            <Card className="bg-gray-50">
              <CardHeader>
                <CardTitle className="text-lg">Study Materials: {topic}</CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs value={activeTab} onValueChange={setActiveTab}>
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="notes" disabled={!notes}>
                      <BookOpen className="h-4 w-4 mr-2" />
                      Study Notes
                      {notes && <span className="ml-2 text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">Ready</span>}
                    </TabsTrigger>
                    <TabsTrigger value="questions" disabled={!questions}>
                      <HelpCircle className="h-4 w-4 mr-2" />
                      Practice Questions
                      {questions && (
                        <span className="ml-2 text-xs bg-green-100 text-green-800 px-2 py-1 rounded">Ready</span>
                      )}
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="notes" className="mt-4">
                    {notes && (
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <h3 className="font-semibold">Study Notes ({noteLength})</h3>
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline" onClick={() => copyToClipboard(notes)}>
                              <Copy className="h-4 w-4 mr-1" />
                              Copy
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => downloadContent(notes, "notes")}>
                              <Download className="h-4 w-4 mr-1" />
                              Download
                            </Button>
                          </div>
                        </div>
                        <Textarea value={notes} readOnly className="min-h-[400px] bg-white" />
                      </div>
                    )}
                  </TabsContent>

                  <TabsContent value="questions" className="mt-4">
                    {questions && (
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <h3 className="font-semibold">Practice Questions</h3>
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline" onClick={() => copyToClipboard(questions)}>
                              <Copy className="h-4 w-4 mr-1" />
                              Copy
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => downloadContent(questions, "questions")}>
                              <Download className="h-4 w-4 mr-1" />
                              Download
                            </Button>
                          </div>
                        </div>
                        <Textarea value={questions} readOnly className="min-h-[400px] bg-white" />
                      </div>
                    )}
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          )}

          {/* Feature Information */}
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="bg-blue-50">
              <CardContent className="p-4">
                <h4 className="font-semibold text-blue-900 mb-4">📝 Note Length Options</h4>
                <ul className="text-blue-800 text-sm space-y-2">
                  <li>
                    • <strong>Very Short:</strong> Quick overview and key points
                  </li>
                  <li>
                    • <strong>Short:</strong> Brief summary with main concepts
                  </li>
                  <li>
                    • <strong>Medium:</strong> Detailed notes with examples
                  </li>
                  <li>
                    • <strong>Long:</strong> Comprehensive guide with depth
                  </li>
                  <li>
                    • <strong>Very Long:</strong> In-depth analysis and details
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-green-50">
              <CardContent className="p-4">
                <h4 className="font-semibold text-green-900 mb-4">❓ Question Types</h4>
                <ul className="text-green-800 text-sm space-y-2">
                  <li>• Multiple choice questions</li>
                  <li>• Short answer questions</li>
                  <li>• Essay questions</li>
                  <li>• True/False questions</li>
                  <li>• Application-based problems</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
