"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Brain, BookOpen, HelpCircle, Mic, Trophy, Calendar, ImageIcon, History } from "lucide-react"
import NotesGenerator from "@/components/notes-generator"
import QuizGenerator from "@/components/quiz-generator"
import VoiceMode from "@/components/voice-mode"
import Leaderboard from "@/components/leaderboard"
import StudyPlanner from "@/components/study-planner"
import ImageDoubtSolver from "@/components/image-doubt-solver"
import StudyHistory from "@/components/study-history"

type ActiveTab = "dashboard" | "notes" | "quiz" | "voice" | "leaderboard" | "planner" | "doubt" | "history"

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState<ActiveTab>("dashboard")
  const [userXP, setUserXP] = useState(0)

  const handleXPUpdate = (newXP: number) => {
    setUserXP((prev) => prev + newXP)
  }

  const backToDashboard = () => {
    setActiveTab("dashboard")
  }

  const features = [
    {
      id: "notes" as ActiveTab,
      title: "Notes Generator",
      description: "Generate AI-powered study notes on any topic",
      icon: BookOpen,
      color: "bg-blue-500",
    },
    {
      id: "quiz" as ActiveTab,
      title: "Quiz Generator",
      description: "Create quizzes and earn XP by completing them",
      icon: HelpCircle,
      color: "bg-green-500",
    },
    {
      id: "voice" as ActiveTab,
      title: "Voice Mode",
      description: "Speak commands to interact with StudyBuddyAI",
      icon: Mic,
      color: "bg-purple-500",
    },
    {
      id: "leaderboard" as ActiveTab,
      title: "XP Leaderboard",
      description: "See how you rank against other students",
      icon: Trophy,
      color: "bg-yellow-500",
    },
    {
      id: "planner" as ActiveTab,
      title: "Study Planner",
      description: "Get personalized study plans from AI",
      icon: Calendar,
      color: "bg-red-500",
    },
    {
      id: "doubt" as ActiveTab,
      title: "Doubt Solver",
      description: "Upload images or type questions for instant answers",
      icon: ImageIcon,
      color: "bg-indigo-500",
    },
    {
      id: "history" as ActiveTab,
      title: "Study History",
      description: "Track your learning progress and XP growth",
      icon: History,
      color: "bg-pink-500",
    },
  ]

  if (activeTab !== "dashboard") {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="bg-white shadow-sm border-b">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <div className="flex items-center gap-4">
                <Button variant="ghost" onClick={backToDashboard} className="flex items-center gap-2">
                  <Brain className="h-5 w-5" />
                  StudyBuddyAI
                </Button>
                <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                  {userXP} XP
                </Badge>
              </div>
              <div className="flex items-center gap-4">
                <span className="text-sm text-gray-600">Demo User</span>
              </div>
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {activeTab === "notes" && <NotesGenerator onBackToDashboard={backToDashboard} />}
          {activeTab === "quiz" && <QuizGenerator onXPUpdate={handleXPUpdate} onBackToDashboard={backToDashboard} />}
          {activeTab === "voice" && <VoiceMode setActiveTab={setActiveTab} onBackToDashboard={backToDashboard} />}
          {activeTab === "leaderboard" && <Leaderboard onBackToDashboard={backToDashboard} />}
          {activeTab === "planner" && <StudyPlanner onBackToDashboard={backToDashboard} />}
          {activeTab === "doubt" && <ImageDoubtSolver onBackToDashboard={backToDashboard} />}
          {activeTab === "history" && <StudyHistory onBackToDashboard={backToDashboard} />}
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <Brain className="h-8 w-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-900">StudyBuddyAI</h1>
            </div>
            <div className="flex items-center gap-4">
              <Badge className="bg-blue-600 text-white px-3 py-1">{userXP} XP</Badge>
              <span className="text-sm text-gray-600">Welcome, Demo User!</span>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Choose Your Learning Adventure</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Explore our AI-powered study tools, complete quizzes to earn XP, and climb the leaderboard!
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature) => {
            const IconComponent = feature.icon
            return (
              <Card
                key={feature.id}
                className="cursor-pointer hover:shadow-lg transition-shadow group"
                onClick={() => setActiveTab(feature.id)}
              >
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div
                      className={`p-2 rounded-lg ${feature.color} text-white group-hover:scale-110 transition-transform`}
                    >
                      <IconComponent className="h-6 w-6" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{feature.title}</CardTitle>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">{feature.description}</CardDescription>
                </CardContent>
              </Card>
            )
          })}
        </div>

        <div className="mt-12 text-center">
          <Card className="max-w-md mx-auto bg-gradient-to-r from-blue-500 to-purple-600 text-white">
            <CardContent className="p-6">
              <Trophy className="h-12 w-12 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">Your XP Journey</h3>
              <p className="text-blue-100 mb-4">Complete quizzes to earn XP and climb the leaderboard!</p>
              <div className="text-3xl font-bold">{userXP} XP</div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
