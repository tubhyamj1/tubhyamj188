"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Trophy, Medal, Award, Crown, ArrowLeft } from "lucide-react"

const mockLeaderboard = [
  { name: "Alice Johnson", email: "alice@example.com", xp: 850, rank: 1 },
  { name: "Bob Smith", email: "bob@example.com", xp: 720, rank: 2 },
  { name: "Carol Davis", email: "carol@example.com", xp: 680, rank: 3 },
  { name: "Demo User", email: "demo@example.com", xp: 0, rank: 4 },
  { name: "Eve Wilson", email: "eve@example.com", xp: 450, rank: 5 },
  { name: "Frank Brown", email: "frank@example.com", xp: 320, rank: 6 },
]

interface LeaderboardProps {
  onBackToDashboard?: () => void
}

export default function Leaderboard({ onBackToDashboard }: LeaderboardProps) {
  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Crown className="h-6 w-6 text-yellow-500" />
      case 2:
        return <Trophy className="h-6 w-6 text-gray-400" />
      case 3:
        return <Medal className="h-6 w-6 text-orange-500" />
      default:
        return <Award className="h-6 w-6 text-blue-500" />
    }
  }

  const getRankBadge = (rank: number) => {
    if (rank === 1) return "bg-yellow-500 text-white"
    if (rank === 2) return "bg-gray-400 text-white"
    if (rank === 3) return "bg-orange-500 text-white"
    return "bg-blue-500 text-white"
  }

  const currentUser = mockLeaderboard.find((entry) => entry.name === "Demo User")

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Back to Dashboard Button */}
      {onBackToDashboard && (
        <div className="mb-6">
          <Button variant="ghost" onClick={onBackToDashboard} className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back to Dashboard
          </Button>
        </div>
      )}

      {/* Current User Stats */}
      {currentUser && (
        <Card className="bg-gradient-to-r from-blue-500 to-purple-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold">Your Ranking</h3>
                <p className="text-blue-100">Keep completing quizzes to climb higher!</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold">#{currentUser.rank}</div>
                <div className="text-sm text-blue-100">{currentUser.xp} XP</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Leaderboard */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Trophy className="h-6 w-6 text-yellow-500" />
            <CardTitle>XP Leaderboard</CardTitle>
          </div>
          <CardDescription>Top students ranked by XP earned from completing quizzes</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {mockLeaderboard.map((entry) => (
              <div
                key={entry.email}
                className={`flex items-center justify-between p-4 rounded-lg border ${
                  entry.name === "Demo User" ? "bg-blue-50 border-blue-200" : "bg-gray-50 border-gray-200"
                }`}
              >
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    {getRankIcon(entry.rank)}
                    <Badge className={getRankBadge(entry.rank)}>#{entry.rank}</Badge>
                  </div>
                  <div>
                    <div className="font-semibold">
                      {entry.name}
                      {entry.name === "Demo User" && <span className="ml-2 text-sm text-blue-600">(You)</span>}
                    </div>
                    <div className="text-sm text-gray-600">{entry.email}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xl font-bold text-blue-600">{entry.xp}</div>
                  <div className="text-sm text-gray-600">XP</div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* XP Information */}
      <Card className="bg-green-50">
        <CardContent className="p-6">
          <h3 className="font-semibold text-green-900 mb-3">🎯 How to Earn XP</h3>
          <div className="space-y-2 text-green-800">
            <p>• Complete quizzes to earn XP (10 XP per correct answer)</p>
            <p>• XP is only awarded when you finish a complete quiz</p>
            <p>• Climb the leaderboard by consistently studying and taking quizzes</p>
            <p>• Challenge your classmates to see who can learn the most!</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
