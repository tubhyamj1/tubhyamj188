"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { History, TrendingUp, Award, Calendar, Target, ArrowLeft } from "lucide-react"

const mockQuizHistory = [
  {
    id: "1",
    topic: "Biology",
    total_questions: 5,
    correct_answers: 4,
    xp_earned: 40,
    completed_at: "2024-01-15T10:30:00Z",
  },
  {
    id: "2",
    topic: "Mathematics",
    total_questions: 5,
    correct_answers: 3,
    xp_earned: 30,
    completed_at: "2024-01-14T14:20:00Z",
  },
  {
    id: "3",
    topic: "History",
    total_questions: 5,
    correct_answers: 5,
    xp_earned: 50,
    completed_at: "2024-01-13T09:15:00Z",
  },
]

interface StudyHistoryProps {
  onBackToDashboard?: () => void
}

export default function StudyHistory({ onBackToDashboard }: StudyHistoryProps) {
  const totalXP = mockQuizHistory.reduce((sum, quiz) => sum + quiz.xp_earned, 0)
  const totalQuizzes = mockQuizHistory.length
  const avgScore =
    mockQuizHistory.length > 0
      ? Math.round(
          mockQuizHistory.reduce((sum, quiz) => sum + (quiz.correct_answers / quiz.total_questions) * 100, 0) /
            mockQuizHistory.length,
        )
      : 0

  const uniqueTopics = new Set(mockQuizHistory.map((quiz) => quiz.topic)).size

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Back to Dashboard Button */}
      {onBackToDashboard && (
        <div className="mb-6">
          <Button variant="ghost" onClick={onBackToDashboard} className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back to Dashboard
          </Button>
        </div>
      )}

      {/* Header */}
      <div className="flex items-center gap-2">
        <History className="h-6 w-6 text-pink-600" />
        <h1 className="text-2xl font-bold">Study History</h1>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6 text-center">
            <Award className="h-8 w-8 mx-auto mb-2 text-yellow-500" />
            <div className="text-2xl font-bold text-yellow-600">{totalXP}</div>
            <div className="text-sm text-gray-600">Total XP Earned</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 text-center">
            <Target className="h-8 w-8 mx-auto mb-2 text-blue-500" />
            <div className="text-2xl font-bold text-blue-600">{totalQuizzes}</div>
            <div className="text-sm text-gray-600">Quizzes Completed</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 text-center">
            <TrendingUp className="h-8 w-8 mx-auto mb-2 text-green-500" />
            <div className="text-2xl font-bold text-green-600">{avgScore}%</div>
            <div className="text-sm text-gray-600">Average Score</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 text-center">
            <Calendar className="h-8 w-8 mx-auto mb-2 text-purple-500" />
            <div className="text-2xl font-bold text-purple-600">{uniqueTopics}</div>
            <div className="text-sm text-gray-600">Topics Studied</div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Quiz History */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Quiz History</CardTitle>
          <CardDescription>Your latest quiz attempts and scores</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {mockQuizHistory.map((quiz) => (
              <div key={quiz.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex-1">
                  <h4 className="font-semibold">{quiz.topic}</h4>
                  <p className="text-sm text-gray-600">
                    {new Date(quiz.completed_at).toLocaleDateString()} at{" "}
                    {new Date(quiz.completed_at).toLocaleTimeString()}
                  </p>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-center">
                    <div className="text-sm font-semibold">
                      {quiz.correct_answers}/{quiz.total_questions}
                    </div>
                    <div className="text-xs text-gray-600">Correct</div>
                  </div>
                  <Badge
                    variant={
                      quiz.correct_answers / quiz.total_questions >= 0.8
                        ? "default"
                        : quiz.correct_answers / quiz.total_questions >= 0.6
                          ? "secondary"
                          : "destructive"
                    }
                  >
                    {Math.round((quiz.correct_answers / quiz.total_questions) * 100)}%
                  </Badge>
                  <div className="text-center">
                    <div className="text-sm font-semibold text-green-600">+{quiz.xp_earned}</div>
                    <div className="text-xs text-gray-600">XP</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
