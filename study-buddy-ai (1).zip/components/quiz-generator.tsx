"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { HelpCircle, Loader2, Trophy, CheckCircle, XCircle, ArrowLeft, RotateCcw } from "lucide-react"

interface QuizGeneratorProps {
  onXPUpdate: (xp: number) => void
  onBackToDashboard?: () => void
}

interface Question {
  question: string
  options: string[]
  correctAnswer: number
}

interface Quiz {
  title: string
  questions: Question[]
}

export default function QuizGenerator({ onXPUpdate, onBackToDashboard }: QuizGeneratorProps) {
  const [topic, setTopic] = useState("")
  const [questionCount, setQuestionCount] = useState("5")
  const [quiz, setQuiz] = useState<Quiz | null>(null)
  const [loading, setLoading] = useState(false)
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([])
  const [showResults, setShowResults] = useState(false)
  const [score, setScore] = useState(0)
  const [showAnswerFeedback, setShowAnswerFeedback] = useState(false)
  const [answerSubmitted, setAnswerSubmitted] = useState(false)

  const generateQuiz = async () => {
    if (!topic.trim()) return

    setLoading(true)
    try {
      const response = await fetch("/api/generate-quiz", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ topic, questionCount: Number.parseInt(questionCount) }),
      })

      const data = await response.json()
      setQuiz(data.quiz)
      setCurrentQuestion(0)
      setSelectedAnswers([])
      setShowResults(false)
      setShowAnswerFeedback(false)
      setAnswerSubmitted(false)
    } catch (error) {
      console.error("Error generating quiz:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleAnswerSelect = (answerIndex: number) => {
    if (answerSubmitted) return // Prevent changing answer after submission

    const newAnswers = [...selectedAnswers]
    newAnswers[currentQuestion] = answerIndex
    setSelectedAnswers(newAnswers)
  }

  const submitAnswer = () => {
    if (selectedAnswers[currentQuestion] === undefined) return

    setAnswerSubmitted(true)
    setShowAnswerFeedback(true)
  }

  const nextQuestion = () => {
    if (currentQuestion < quiz!.questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
      setShowAnswerFeedback(false)
      setAnswerSubmitted(false)
    } else {
      completeQuiz()
    }
  }

  const previousQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1)
      setShowAnswerFeedback(false)
      setAnswerSubmitted(false)
    }
  }

  const completeQuiz = () => {
    if (!quiz) return

    let correctCount = 0
    quiz.questions.forEach((q, index) => {
      if (selectedAnswers[index] === q.correctAnswer) {
        correctCount++
      }
    })

    setScore(correctCount)
    setShowResults(true)

    // Award XP (10 XP per correct answer)
    const xpEarned = correctCount * 10
    onXPUpdate(xpEarned)
  }

  const resetQuiz = () => {
    setQuiz(null)
    setTopic("")
    setCurrentQuestion(0)
    setSelectedAnswers([])
    setShowResults(false)
    setShowAnswerFeedback(false)
    setAnswerSubmitted(false)
  }

  const getQuestionCountDescription = (count: string) => {
    switch (count) {
      case "5":
        return "Quick quiz (5 minutes)"
      case "10":
        return "Standard quiz (10 minutes)"
      case "15":
        return "Extended quiz (15 minutes)"
      case "20":
        return "Long quiz (20 minutes)"
      case "25":
        return "Comprehensive quiz (25 minutes)"
      case "30":
        return "Full assessment (30 minutes)"
      default:
        return "Standard length"
    }
  }

  if (showResults && quiz) {
    const xpEarned = score * 10
    const percentage = Math.round((score / quiz.questions.length) * 100)

    return (
      <div className="max-w-4xl mx-auto">
        {/* Back to Dashboard Button */}
        {onBackToDashboard && (
          <div className="mb-6">
            <Button variant="ghost" onClick={onBackToDashboard} className="flex items-center gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Dashboard
            </Button>
          </div>
        )}

        <Card>
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <Trophy className="h-16 w-16 text-yellow-500" />
            </div>
            <CardTitle className="text-2xl">Quiz Completed!</CardTitle>
            <CardDescription>Here are your results for {quiz.title}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-blue-50 rounded-lg text-center">
                <div className="text-2xl font-bold text-blue-600">
                  {score}/{quiz.questions.length}
                </div>
                <div className="text-sm text-gray-600">Correct Answers</div>
              </div>
              <div className="p-4 bg-purple-50 rounded-lg text-center">
                <div className="text-2xl font-bold text-purple-600">{percentage}%</div>
                <div className="text-sm text-gray-600">Score Percentage</div>
              </div>
              <div className="p-4 bg-green-50 rounded-lg text-center">
                <div className="text-2xl font-bold text-green-600">+{xpEarned} XP</div>
                <div className="text-sm text-gray-600">Points Earned</div>
              </div>
            </div>

            {/* Detailed Results */}
            <Card className="bg-gray-50">
              <CardHeader>
                <CardTitle className="text-lg">Question Review</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {quiz.questions.map((q, index) => {
                  const isCorrect = selectedAnswers[index] === q.correctAnswer
                  const userAnswer = selectedAnswers[index]

                  return (
                    <div key={index} className="p-4 bg-white rounded-lg border">
                      <div className="flex items-start gap-3 mb-3">
                        {isCorrect ? (
                          <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                        ) : (
                          <XCircle className="h-5 w-5 text-red-500 mt-1 flex-shrink-0" />
                        )}
                        <div className="flex-1">
                          <h4 className="font-semibold text-gray-900 mb-2">
                            Q{index + 1}: {q.question}
                          </h4>

                          <div className="space-y-2">
                            {!isCorrect && userAnswer !== undefined && (
                              <div className="p-2 bg-red-50 rounded border-l-4 border-red-400">
                                <span className="text-sm text-red-800">
                                  <strong>Your answer:</strong> {q.options[userAnswer]}
                                </span>
                              </div>
                            )}

                            <div className="p-2 bg-green-50 rounded border-l-4 border-green-400">
                              <span className="text-sm text-green-800">
                                <strong>Correct answer:</strong> {q.options[q.correctAnswer]}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )
                })}
              </CardContent>
            </Card>

            <div className="flex gap-4 justify-center">
              <Button onClick={resetQuiz}>
                <RotateCcw className="h-4 w-4 mr-2" />
                Take Another Quiz
              </Button>
              {onBackToDashboard && (
                <Button variant="outline" onClick={onBackToDashboard}>
                  Back to Dashboard
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (quiz) {
    const question = quiz.questions[currentQuestion]
    const isAnswerCorrect = selectedAnswers[currentQuestion] === question.correctAnswer
    const hasSelectedAnswer = selectedAnswers[currentQuestion] !== undefined

    return (
      <div className="max-w-3xl mx-auto">
        {/* Back to Dashboard Button */}
        {onBackToDashboard && (
          <div className="mb-6">
            <Button variant="ghost" onClick={onBackToDashboard} className="flex items-center gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Dashboard
            </Button>
          </div>
        )}

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <HelpCircle className="h-6 w-6 text-green-600" />
                <CardTitle>{quiz.title}</CardTitle>
              </div>
              <Badge variant="outline">
                {currentQuestion + 1} of {quiz.questions.length}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Progress Bar */}
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-green-600 h-2 rounded-full transition-all"
                style={{ width: `${((currentQuestion + 1) / quiz.questions.length) * 100}%` }}
              />
            </div>

            {/* Question */}
            <div>
              <h3 className="text-lg font-semibold mb-4">{question.question}</h3>

              <RadioGroup
                value={selectedAnswers[currentQuestion]?.toString() || ""}
                onValueChange={(value) => handleAnswerSelect(Number.parseInt(value))}
                disabled={answerSubmitted}
              >
                {question.options.map((option, index) => {
                  let optionClass = "flex items-center space-x-2 p-3 rounded-lg border transition-colors"

                  if (showAnswerFeedback) {
                    if (index === question.correctAnswer) {
                      optionClass += " bg-green-50 border-green-300"
                    } else if (index === selectedAnswers[currentQuestion] && index !== question.correctAnswer) {
                      optionClass += " bg-red-50 border-red-300"
                    } else {
                      optionClass += " bg-gray-50 border-gray-200"
                    }
                  } else {
                    optionClass += " hover:bg-gray-50 border-gray-200"
                  }

                  return (
                    <div key={index} className={optionClass}>
                      <RadioGroupItem value={index.toString()} id={`option-${index}`} disabled={answerSubmitted} />
                      <Label htmlFor={`option-${index}`} className="flex-1 cursor-pointer">
                        {option}
                      </Label>
                      {showAnswerFeedback && index === question.correctAnswer && (
                        <CheckCircle className="h-5 w-5 text-green-500" />
                      )}
                      {showAnswerFeedback &&
                        index === selectedAnswers[currentQuestion] &&
                        index !== question.correctAnswer && <XCircle className="h-5 w-5 text-red-500" />}
                    </div>
                  )
                })}
              </RadioGroup>
            </div>

            {/* Answer Feedback */}
            {showAnswerFeedback && (
              <Card className={isAnswerCorrect ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"}>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    {isAnswerCorrect ? (
                      <CheckCircle className="h-5 w-5 text-green-600" />
                    ) : (
                      <XCircle className="h-5 w-5 text-red-600" />
                    )}
                    <span className={`font-semibold ${isAnswerCorrect ? "text-green-800" : "text-red-800"}`}>
                      {isAnswerCorrect ? "Correct!" : "Incorrect"}
                    </span>
                  </div>
                  {!isAnswerCorrect && (
                    <p className="text-red-700 text-sm">
                      The correct answer is: <strong>{question.options[question.correctAnswer]}</strong>
                    </p>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Navigation Buttons */}
            <div className="flex justify-between">
              <Button variant="outline" onClick={previousQuestion} disabled={currentQuestion === 0}>
                Previous
              </Button>

              <div className="flex gap-2">
                {!answerSubmitted && hasSelectedAnswer && <Button onClick={submitAnswer}>Submit Answer</Button>}

                {answerSubmitted && (
                  <Button onClick={nextQuestion}>
                    {currentQuestion === quiz.questions.length - 1 ? "Complete Quiz" : "Next Question"}
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="max-w-3xl mx-auto">
      {/* Back to Dashboard Button */}
      {onBackToDashboard && (
        <div className="mb-6">
          <Button variant="ghost" onClick={onBackToDashboard} className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back to Dashboard
          </Button>
        </div>
      )}

      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <HelpCircle className="h-6 w-6 text-green-600" />
            <CardTitle>AI Quiz Generator</CardTitle>
          </div>
          <CardDescription>
            Generate interactive quizzes on any topic with customizable length and earn XP for correct answers!
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Input Section */}
          <div className="grid md:grid-cols-3 gap-4">
            <div className="md:col-span-2">
              <Label htmlFor="topic">Quiz Topic</Label>
              <Input
                id="topic"
                placeholder="Enter a topic (e.g., Biology, Mathematics, History)"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && generateQuiz()}
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="questionCount">Number of Questions</Label>
              <Select value={questionCount} onValueChange={setQuestionCount}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Select count" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="5">5 Questions</SelectItem>
                  <SelectItem value="10">10 Questions</SelectItem>
                  <SelectItem value="15">15 Questions</SelectItem>
                  <SelectItem value="20">20 Questions</SelectItem>
                  <SelectItem value="25">25 Questions</SelectItem>
                  <SelectItem value="30">30 Questions</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-gray-500 mt-1">{getQuestionCountDescription(questionCount)}</p>
            </div>
          </div>

          {/* Generate Button */}
          <Button onClick={generateQuiz} disabled={loading || !topic.trim()} className="w-full">
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Generating {questionCount} Questions...
              </>
            ) : (
              <>
                <HelpCircle className="h-4 w-4 mr-2" />
                Generate {questionCount} Question Quiz
              </>
            )}
          </Button>

          {/* Feature Information */}
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="bg-blue-50">
              <CardContent className="p-4">
                <h4 className="font-semibold text-blue-900 mb-4">🏆 XP Rewards</h4>
                <ul className="text-blue-800 text-sm space-y-2">
                  <li>
                    • <strong>10 XP</strong> for each correct answer
                  </li>
                  <li>• Instant feedback on your answers</li>
                  <li>• Detailed review after completion</li>
                  <li>• Track your progress over time</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-green-50">
              <CardContent className="p-4">
                <h4 className="font-semibold text-green-900 mb-4">📊 Quiz Features</h4>
                <ul className="text-green-800 text-sm space-y-2">
                  <li>• Choose from 5 to 30 questions</li>
                  <li>• See correct answers when wrong</li>
                  <li>• Progress tracking and scoring</li>
                  <li>• Comprehensive result review</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
