"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Mic, MicOff, Volume2, ArrowLeft, Brain } from "lucide-react"

interface VoiceModeProps {
  setActiveTab: (tab: string) => void
  onBackToDashboard?: () => void
}

export default function VoiceMode({ setActiveTab, onBackToDashboard }: VoiceModeProps) {
  const [isListening, setIsListening] = useState(false)
  const [transcript, setTranscript] = useState("")
  const [response, setResponse] = useState("")
  const [recognition, setRecognition] = useState<any>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [conversationHistory, setConversationHistory] = useState<Array<{ question: string; answer: string }>>([])

  useEffect(() => {
    if (typeof window !== "undefined" && "webkitSpeechRecognition" in window) {
      const recognition = new (window as any).webkitSpeechRecognition()
      recognition.continuous = false
      recognition.interimResults = false
      recognition.lang = "en-US"

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript
        setTranscript(transcript)
        processVoiceCommand(transcript)
      }

      recognition.onend = () => {
        setIsListening(false)
      }

      setRecognition(recognition)
    }
  }, [])

  const startListening = () => {
    if (recognition) {
      setIsListening(true)
      setTranscript("")
      setResponse("")
      recognition.start()
    }
  }

  const stopListening = () => {
    if (recognition) {
      recognition.stop()
      setIsListening(false)
    }
  }

  const processVoiceCommand = async (command: string) => {
    const lowerCommand = command.toLowerCase()
    setIsProcessing(true)

    try {
      // Navigation commands
      if (lowerCommand.includes("quiz") || lowerCommand.includes("test")) {
        setResponse("Opening Quiz Generator...")
        speakResponse("Opening Quiz Generator for you")
        setTimeout(() => setActiveTab("quiz"), 1500)
      } else if (lowerCommand.includes("notes") || lowerCommand.includes("study notes")) {
        setResponse("Opening Notes Generator...")
        speakResponse("Opening Notes Generator for you")
        setTimeout(() => setActiveTab("notes"), 1500)
      } else if (lowerCommand.includes("leaderboard") || lowerCommand.includes("ranking")) {
        setResponse("Opening XP Leaderboard...")
        speakResponse("Opening XP Leaderboard to show your ranking")
        setTimeout(() => setActiveTab("leaderboard"), 1500)
      } else if (lowerCommand.includes("planner") || lowerCommand.includes("schedule")) {
        setResponse("Opening Study Planner...")
        speakResponse("Opening Study Planner to help organize your studies")
        setTimeout(() => setActiveTab("planner"), 1500)
      } else if (lowerCommand.includes("doubt") || lowerCommand.includes("question")) {
        setResponse("Opening Doubt Solver...")
        speakResponse("Opening Doubt Solver to help answer your questions")
        setTimeout(() => setActiveTab("doubt"), 1500)
      } else if (lowerCommand.includes("history") || lowerCommand.includes("progress")) {
        setResponse("Opening Study History...")
        speakResponse("Opening Study History to show your learning progress")
        setTimeout(() => setActiveTab("history"), 1500)
      } else if (lowerCommand.includes("dashboard") || lowerCommand.includes("home")) {
        setResponse("Going back to Dashboard...")
        speakResponse("Taking you back to the main dashboard")
        setTimeout(() => setActiveTab("dashboard"), 1500)
      }
      // Question answering commands
      else if (
        lowerCommand.includes("what is") ||
        lowerCommand.includes("how do") ||
        lowerCommand.includes("explain") ||
        lowerCommand.includes("define") ||
        lowerCommand.includes("solve") ||
        lowerCommand.includes("calculate") ||
        lowerCommand.includes("tell me about") ||
        lowerCommand.includes("help me with")
      ) {
        setResponse("Let me help you with that question...")
        const answer = await getAIResponse(command)
        setResponse(answer)
        speakResponse(answer)

        // Add to conversation history
        setConversationHistory((prev) => [...prev, { question: command, answer }])
      }
      // Greeting commands
      else if (lowerCommand.includes("hello") || lowerCommand.includes("hi") || lowerCommand.includes("hey")) {
        const greeting =
          "Hello! I'm your StudyBuddyAI voice assistant. You can ask me questions, request explanations, or navigate to different features. How can I help you study today?"
        setResponse(greeting)
        speakResponse(greeting)
      }
      // Help commands
      else if (lowerCommand.includes("help") || lowerCommand.includes("what can you do")) {
        const helpText =
          "I can help you in several ways: Answer academic questions, explain concepts, solve problems, navigate to quiz generator, notes generator, study planner, and more. Just speak naturally and ask me anything!"
        setResponse(helpText)
        speakResponse(helpText)
      }
      // Default response for unrecognized commands
      else {
        const defaultResponse = `I heard: "${command}". You can ask me questions like "What is photosynthesis?", "How do I solve quadratic equations?", or use navigation commands like "open quiz" or "show leaderboard".`
        setResponse(defaultResponse)
        speakResponse("I'm not sure about that command. You can ask me academic questions or use navigation commands.")
      }
    } catch (error) {
      console.error("Error processing voice command:", error)
      const errorResponse = "Sorry, I encountered an error processing your request. Please try again."
      setResponse(errorResponse)
      speakResponse(errorResponse)
    } finally {
      setIsProcessing(false)
    }
  }

  const getAIResponse = async (question: string): Promise<string> => {
    try {
      const response = await fetch("/api/solve-text-doubt", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ question }),
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const data = await response.json()

      // Return the full response instead of truncating it
      const fullResponse = data.response || "I couldn't generate a response for that question."

      return fullResponse
    } catch (error) {
      console.error("Error getting AI response:", error)
      return "I'm having trouble accessing my knowledge base right now. Please try asking your question again or use the Doubt Solver feature."
    }
  }

  const speakResponse = (text: string) => {
    if ("speechSynthesis" in window) {
      // Cancel any ongoing speech
      speechSynthesis.cancel()

      // For very long responses, create a shorter spoken version
      let spokenText = text

      // If the text is very long (over 500 characters), create a summary for speech
      if (text.length > 500) {
        // Extract key points or first few sentences for speech
        const sentences = text.split(/[.!?]+/).filter((sentence) => sentence.trim().length > 10)

        // Take first 2-3 sentences or up to 400 characters
        let summary = ""
        for (let i = 0; i < Math.min(3, sentences.length); i++) {
          if ((summary + sentences[i]).length < 400) {
            summary += sentences[i].trim() + ". "
          } else {
            break
          }
        }

        spokenText = summary || text.substring(0, 400) + "..."

        // Add a note about the full answer being displayed
        spokenText += " The complete detailed answer is shown on screen."
      }

      const utterance = new SpeechSynthesisUtterance(spokenText)
      utterance.rate = 0.9
      utterance.pitch = 1
      utterance.volume = 0.8

      // Use a more natural voice if available
      const voices = speechSynthesis.getVoices()
      const preferredVoice = voices.find(
        (voice) => voice.name.includes("Google") || voice.name.includes("Microsoft") || voice.lang.includes("en-US"),
      )
      if (preferredVoice) {
        utterance.voice = preferredVoice
      }

      speechSynthesis.speak(utterance)
    }
  }

  const clearConversation = () => {
    setConversationHistory([])
    setResponse("")
    setTranscript("")
  }

  return (
    <div className="max-w-4xl mx-auto">
      {/* Back to Dashboard Button */}
      {onBackToDashboard && (
        <div className="mb-6">
          <Button variant="ghost" onClick={onBackToDashboard} className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back to Dashboard
          </Button>
        </div>
      )}

      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Mic className="h-6 w-6 text-purple-600" />
            <CardTitle>Voice Assistant</CardTitle>
          </div>
          <CardDescription>
            Ask questions, get explanations, or navigate StudyBuddyAI with voice commands
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center">
            <div className="mb-6">
              <Button
                onClick={isListening ? stopListening : startListening}
                size="lg"
                disabled={isProcessing}
                className={`w-32 h-32 rounded-full ${
                  isListening
                    ? "bg-red-500 hover:bg-red-600 animate-pulse"
                    : isProcessing
                      ? "bg-orange-500 hover:bg-orange-600"
                      : "bg-purple-500 hover:bg-purple-600"
                }`}
              >
                {isListening ? (
                  <MicOff className="h-12 w-12" />
                ) : isProcessing ? (
                  <Brain className="h-12 w-12 animate-spin" />
                ) : (
                  <Mic className="h-12 w-12" />
                )}
              </Button>
            </div>

            <Badge variant={isListening ? "destructive" : isProcessing ? "secondary" : "secondary"} className="mb-4">
              {isListening ? "Listening..." : isProcessing ? "Processing..." : "Ready to Listen"}
            </Badge>
          </div>

          {transcript && (
            <Card className="bg-blue-50">
              <CardContent className="p-4">
                <h4 className="font-semibold text-blue-900 mb-2">You said:</h4>
                <p className="text-blue-800">"{transcript}"</p>
              </CardContent>
            </Card>
          )}

          {response && (
            <Card className="bg-green-50">
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h4 className="font-semibold text-green-900 mb-2">AI Response:</h4>
                    <p className="text-green-800">{response}</p>
                  </div>
                  <Button size="sm" variant="outline" onClick={() => speakResponse(response)}>
                    <Volume2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Conversation History */}
          {conversationHistory.length > 0 && (
            <Card className="bg-gray-50">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-lg">Conversation History</CardTitle>
                <Button size="sm" variant="outline" onClick={clearConversation}>
                  Clear History
                </Button>
              </CardHeader>
              <CardContent className="space-y-3 max-h-60 overflow-y-auto">
                {conversationHistory.slice(-3).map((item, index) => (
                  <div key={index} className="p-3 bg-white rounded border">
                    <div className="text-sm font-medium text-gray-700 mb-1">Q: {item.question}</div>
                    <div className="text-sm text-gray-600">A: {item.answer.substring(0, 300)}...</div>
                    <Button size="sm" variant="ghost" onClick={() => speakResponse(item.answer)} className="mt-2">
                      <Volume2 className="h-3 w-3 mr-1" />
                      Replay Answer
                    </Button>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          <div className="grid md:grid-cols-2 gap-4">
            <Card className="bg-gray-50">
              <CardContent className="p-4">
                <h4 className="font-semibold text-gray-900 mb-3">🎯 Navigation Commands:</h4>
                <div className="grid grid-cols-1 gap-2 text-sm">
                  <div>"Open quiz" or "Make a quiz"</div>
                  <div>"Generate notes" or "Study notes"</div>
                  <div>"Show leaderboard" or "Rankings"</div>
                  <div>"Study planner" or "Schedule"</div>
                  <div>"Doubt solver" or "Ask question"</div>
                  <div>"Show history" or "My progress"</div>
                  <div>"Go to dashboard" or "Home"</div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-purple-50">
              <CardContent className="p-4">
                <h4 className="font-semibold text-purple-900 mb-3">🧠 Question Examples:</h4>
                <div className="grid grid-cols-1 gap-2 text-sm">
                  <div>"What is photosynthesis?"</div>
                  <div>"How do I solve quadratic equations?"</div>
                  <div>"Explain Newton's laws of motion"</div>
                  <div>"Define mitochondria"</div>
                  <div>"Help me with calculus"</div>
                  <div>"Tell me about World War 2"</div>
                  <div>"Calculate the area of a circle"</div>
                </div>
              </CardContent>
            </Card>
          </div>

          {!recognition && (
            <Card className="bg-yellow-50 border-yellow-200">
              <CardContent className="p-4">
                <p className="text-yellow-800 text-sm">
                  Speech recognition is not supported in your browser. Please use Chrome or Safari for the best
                  experience with voice commands and responses.
                </p>
              </CardContent>
            </Card>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
