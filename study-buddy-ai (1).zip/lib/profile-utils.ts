import { createClient } from "@supabase/supabase-js"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!)

export async function ensureUserProfile(user: any) {
  try {
    // Check if profile exists
    const { data: existingProfile } = await supabase.from("profiles").select("*").eq("email", user.email).single()

    if (existingProfile) {
      return existingProfile
    }

    // Create profile if it doesn't exist
    const { data: newProfile, error } = await supabase
      .from("profiles")
      .insert([
        {
          email: user.email,
          name: user.user_metadata?.name || user.email?.split("@")[0],
          xp: 0,
        },
      ])
      .select()
      .single()

    if (error) {
      console.error("Error creating profile:", error)
      return null
    }

    return newProfile
  } catch (error) {
    console.error("Error ensuring user profile:", error)
    return null
  }
}
